//
//  ZQDownloadViewController.m
//  ChuanKe
//
//  Created by tarena on 15/8/6.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQDownloadViewController.h"

@interface ZQDownloadViewController ()

@end

@implementation ZQDownloadViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    self.view.backgroundColor = [UIColor whiteColor];
    [self setNavi];
    [self initViews];
}

- (void)setNavi {
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_width, 98)];
    backView.backgroundColor = navigationBarColor;
    [self.view addSubview:backView];
    
    //标题
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(screen_width/2-80, 20, 160, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.text = @"离线下载";
    titleLabel.font = [UIFont systemFontOfSize:19];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [backView addSubview:titleLabel];
    
    //segment
    NSArray *segmentArray = @[@"已下载",@"正在下载"];
    UISegmentedControl *segmentControl = [[UISegmentedControl alloc] initWithItems:segmentArray];
    segmentControl.frame = CGRectMake(36, 64, screen_width-36*2, 30);
    segmentControl.selectedSegmentIndex = 0;
    //字体
    NSDictionary *attributes = @{NSFontAttributeName : [UIFont boldSystemFontOfSize:15], NSForegroundColorAttributeName : [UIColor whiteColor]};
    [segmentControl setTitleTextAttributes:attributes forState:UIControlStateNormal];
    NSDictionary *highLightedAttr = @{NSForegroundColorAttributeName : [UIColor whiteColor]};
    [segmentControl setTitleTextAttributes:highLightedAttr forState:UIControlStateHighlighted];
    //背景颜色
    segmentControl.tintColor = RGB(46, 158, 138);
    [backView addSubview:segmentControl];
}

- (void)initViews {
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 98, screen_width, screen_height-98-49)];
    imageView.image = [UIImage imageNamed:@"download_background"];
    [self.view addSubview:imageView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
