//
//  ZQLoginViewController.h
//  ChuanKe
//
//  Created by tarena on 15/8/12.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ZQLoginViewController;

@protocol ZQLoginViewDelegate <NSObject>

- (void)zqLoginView:(ZQLoginViewController *)sender loginUserInfo:(NSDictionary *)dictionary withTag:(NSInteger)tag;

@end

@interface ZQLoginViewController : UIViewController

@property (nonatomic, weak) id<ZQLoginViewDelegate> delegate;

@end
