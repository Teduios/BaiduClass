//
//  ZQMineViewController.m
//  ChuanKe
//
//  Created by tarena on 15/8/6.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQMineViewController.h"
#import "ZQLoginViewController.h"

@interface ZQMineViewController ()<UITableViewDataSource,UITableViewDelegate,ZQLoginViewDelegate>
{
    NSMutableArray *_myCourseArray;
    NSMutableDictionary *_myCourseDic;
    
    UIImageView *_imageView;
    UIButton *_loginButton;
    UILabel *_nickNameLabel;
    UILabel *_classTimeLabel;
    UILabel *_classLabel;
}

@end

@implementation ZQMineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self initData];
    [self initViews];
    [self initTableView];
}

- (void)initData {
    NSString *myCoursePath = [[NSBundle mainBundle] pathForResource:@"myCourse" ofType:@"plist"];
    _myCourseArray = [[NSMutableArray alloc] initWithContentsOfFile:myCoursePath];
    _myCourseDic = [NSMutableDictionary dictionary];
}

- (void)initViews {
    _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, screen_width, 200)];
    _imageView.image = [UIImage imageNamed:@"my_course_back"];
    _imageView.alpha = 0.8;
    [self.view addSubview:_imageView];
    
    _loginButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _loginButton.frame = CGRectMake(screen_width/2-120, 50, 80, 80);
    [_loginButton setImage:[UIImage imageNamed:@"my_course_unlogin"] forState:UIControlStateNormal];
    [_loginButton addTarget:self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_loginButton];
    
    _nickNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(screen_width/2-120, CGRectGetMaxY(_loginButton.frame)+5, 80, 35)];
    _nickNameLabel.textAlignment = NSTextAlignmentCenter;
    _nickNameLabel.textColor = [UIColor whiteColor];
    _nickNameLabel.font = [UIFont systemFontOfSize:20];
    _nickNameLabel.text = @"点击登陆";
    [self.view addSubview:_nickNameLabel];
    
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(screen_width/2-1, 50, 2, 100)];
    lineView.layer.masksToBounds = YES;
    lineView.layer.cornerRadius = 10;
    lineView.backgroundColor = separaterColor;
    [self.view addSubview:lineView];
    
    _classTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(screen_width/2+40, 50, 50, 50)];
    _classTimeLabel.textAlignment = NSTextAlignmentRight;
    _classTimeLabel.textColor = [UIColor whiteColor];
    _classTimeLabel.font = [UIFont systemFontOfSize:40];
    _classTimeLabel.text = @"0";
    [self.view addSubview:_classTimeLabel];
    UILabel *timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_classTimeLabel.frame)+5, CGRectGetMaxY(_classTimeLabel.frame)-20, 40, 20)];
    timeLabel.textColor = [UIColor whiteColor];
    timeLabel.text = @"小时";
    [self.view addSubview:timeLabel];
    

    _classLabel = [[UILabel alloc] initWithFrame:CGRectMake(screen_width/2+40, CGRectGetMaxY(_classTimeLabel.frame)+10, 50, 50)];
    _classLabel.textAlignment = NSTextAlignmentRight;
    _classLabel.textColor = [UIColor whiteColor];
    _classLabel.font = [UIFont systemFontOfSize:40];
    _classLabel.text = @"0";
    [self.view addSubview:_classLabel];
    UILabel *classLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_classLabel.frame)+5, CGRectGetMaxY(_classLabel.frame)-20, 40, 20)];
    classLabel.textColor = [UIColor whiteColor];
    classLabel.text = @"节";
    [self.view addSubview:classLabel];
}

- (void)initTableView {
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 200, screen_width, screen_height-200-49)];
    [self.view addSubview:self.tableView];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
}

#pragma mark -- UITableViewDataSuorce
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _myCourseArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"myCourseCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(15, 10, 30, 30)];
        imageView.tag = 70;
        [cell addSubview:imageView];
        
        //标题
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(60, 10, 100, 30)];
        titleLabel.tag = 71;
        [cell addSubview:titleLabel];
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(20, 49.5, screen_width-20, 0.5)];
        lineView.backgroundColor = separaterColor;
        [cell addSubview:lineView];
    }
    NSDictionary *dataDic = _myCourseArray[indexPath.row];
    UIImageView *imageView = (UIImageView *)[cell viewWithTag:70];
    imageView.image = [UIImage imageNamed:dataDic[@"image"]];
    UILabel *titleLabel = (UILabel *)[cell viewWithTag:71];
    titleLabel.text = dataDic[@"title"];
    return cell;
}

#pragma mark -- UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)login {
    ZQLoginViewController *vc = [[ZQLoginViewController alloc] init];
    vc.delegate = self;
    [self presentViewController:vc animated:YES completion:nil];
}

#pragma mark -- ZQLoginViewDelegate
- (void)zqLoginView:(ZQLoginViewController *)sender loginUserInfo:(NSDictionary *)dictionary withTag:(NSInteger)tag {
    if (tag>=2) {
        NSURL *url = [NSURL URLWithString:dictionary[@"userHeader"]];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSData *data = [NSData dataWithContentsOfURL:url];
            UIImage *image = [UIImage imageWithData:data];
            dispatch_async(dispatch_get_main_queue(), ^{
                [_loginButton setImage:image forState:UIControlStateNormal];
            });
        });
    }else {
        [_loginButton setImage:[UIImage imageNamed:dictionary[@"userHeader"]] forState:UIControlStateNormal];
    }
    _nickNameLabel.text = dictionary[@"username"];
    _classTimeLabel.text = dictionary[@"classTime"];
    _classLabel.text = dictionary[@"class"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
