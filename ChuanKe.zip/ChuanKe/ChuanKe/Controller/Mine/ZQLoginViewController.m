//
//  ZQLoginViewController.m
//  ChuanKe
//
//  Created by tarena on 15/8/12.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQLoginViewController.h"
#import "ZQMineViewController.h"
#import "UMSocial.h"

@interface ZQLoginViewController ()
{
    NSMutableDictionary *_userInfoDic;
    UITextField *_userNameTextField;
    UITextField *_passwordTextField;
}

@end

@implementation ZQLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = RGB(242, 242, 242);
    [self setNavi];
    [self initData];
    [self initViews];
}

- (void)setNavi {
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_width, 64)];
    backView.backgroundColor = navigationBarColor;
    [self.view addSubview:backView];
    
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [backView addSubview:backButton];
    backButton.frame = CGRectMake(0, 20, 40, 40);
    [backButton setImage:[UIImage imageNamed:@"file_tital_back_but"] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(screen_width/2-60, 20, 120, 40)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"登陆上课啦";
    [backView addSubview:titleLabel];
}

- (void)initData {
    NSString *userInfoPath = [[NSBundle mainBundle] pathForResource:@"myCourseInfo" ofType:@"plist"];
    _userInfoDic = [[NSMutableDictionary alloc] initWithContentsOfFile:userInfoPath];
}

- (void)initViews {
    _userNameTextField = [[UITextField alloc] initWithFrame:CGRectMake(10, 64+20, screen_width-20, 50)];
    _userNameTextField.clearButtonMode = UITextFieldViewModeAlways;
    _userNameTextField.placeholder = @"请输入账号";
    _userNameTextField.font = [UIFont systemFontOfSize:15];
    _userNameTextField.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_userNameTextField];
    
    _passwordTextField = [[UITextField alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(_userNameTextField.frame)+10, screen_width-20, 50)];
    _passwordTextField.clearButtonMode = UITextFieldViewModeAlways;
    _passwordTextField.secureTextEntry = YES;
    _passwordTextField.placeholder = @"请输入密码";
    _passwordTextField.font = [UIFont systemFontOfSize:15];
    _passwordTextField.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_passwordTextField];
    
    UIButton *loginButton = [UIButton buttonWithType:UIButtonTypeCustom];
    loginButton.frame = CGRectMake(10, CGRectGetMaxY(_passwordTextField.frame)+10, screen_width-20, 50);
    loginButton.backgroundColor = navigationBarColor;
    [loginButton setTitle:@"登陆" forState:UIControlStateNormal];
    [loginButton addTarget:self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];
    //第三方登陆
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, screen_height-200, screen_width, 20)];
    label.textColor = [UIColor lightGrayColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.text = @"第三方登陆";
    [self.view addSubview:label];
    
    UIButton *qqButton = [UIButton buttonWithType:UIButtonTypeCustom];
    qqButton.frame = CGRectMake(30, CGRectGetMaxY(label.frame)+20, 40, 40);
    [qqButton setImage:[UIImage imageNamed:@"login_qq"] forState:UIControlStateNormal];
    [qqButton addTarget:self action:@selector(loginQQ) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:qqButton];
    
    UIButton *sinaButton = [UIButton buttonWithType:UIButtonTypeCustom];
    sinaButton.frame = CGRectMake(CGRectGetMaxX(qqButton.frame)+(screen_width-180)/2, qqButton.frame.origin.y, 40, 40);
    [sinaButton setImage:[UIImage imageNamed:@"login_sina"] forState:UIControlStateNormal];
    [sinaButton addTarget:self action:@selector(loginSina) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sinaButton];
    
    UIButton *wechatButton = [UIButton buttonWithType:UIButtonTypeCustom];
    wechatButton.frame = CGRectMake(screen_width-30-40, qqButton.frame.origin.y, 40, 40);
    [wechatButton setImage:[UIImage imageNamed:@"login_weixin"] forState:UIControlStateNormal];
    [wechatButton addTarget:self action:@selector(loginWeChat) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:wechatButton];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

- (void)back {
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark -- login
- (void)login {
    NSString *userName = _userInfoDic[@"userName"];
    NSString *password = _userInfoDic[@"password"];
    if ([_userNameTextField.text isEqualToString:userName] && [_passwordTextField.text isEqualToString:password]) {
        [self.delegate zqLoginView:self loginUserInfo:_userInfoDic withTag:1];
        [self dismissViewControllerAnimated:YES completion:nil];
    }else {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"您输入的账号或密码有误" message:@"请确认后输入" delegate:self cancelButtonTitle:@"好" otherButtonTitles:nil, nil];
        [alertView show];
    }
}

- (void)loginQQ {
    UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToQQ];
    snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
        if (response.responseCode == UMSResponseCodeSuccess) {
            UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToQQ];
            NSLog(@"username:%@ url:%@",snsAccount.userName,snsAccount.iconURL);
            //获取用户信息
            NSLog(@"username:%@ url:%@",snsAccount.userName,snsAccount.iconURL);
            NSDictionary *userInfoDic = @{@"username":snsAccount.userName,@"userHeader":snsAccount.iconURL,@"classTime":@"0",@"class":@"0"};
            
            [self.delegate zqLoginView:self loginUserInfo:userInfoDic withTag:2];
            [self dismissViewControllerAnimated:YES completion:nil];
        }
    });
}

- (void)loginSina {
    UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToSina];
    snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
        if (response.responseCode == UMSResponseCodeSuccess) {
            UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToSina];
            //获取用户信息
            NSLog(@"username:%@ url:%@",snsAccount.userName,snsAccount.iconURL);
            NSDictionary *userInfoDic = @{@"username":snsAccount.userName,@"userHeader":snsAccount.iconURL,@"classTime":@"0",@"class":@"0"};
            
            [self.delegate zqLoginView:self loginUserInfo:userInfoDic withTag:3];
            [self dismissViewControllerAnimated:YES completion:nil];
        }
    });
}

- (void)loginWeChat {
    UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToWechatSession];
    snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
        if (response.responseCode == UMSResponseCodeSuccess) {
            UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToWechatSession];
            //获取用户信息
            NSLog(@"username:%@ url:%@",snsAccount.userName,snsAccount.iconURL);
            NSDictionary *userInfoDic = @{@"username":snsAccount.userName,@"userHeader":snsAccount.iconURL,@"classTime":@"0",@"class":@"0"};
            [self.delegate zqLoginView:self loginUserInfo:userInfoDic withTag:4];
            [self dismissViewControllerAnimated:YES completion:nil];
        }
    });
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
