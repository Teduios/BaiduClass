//
//  ZQMineViewController.h
//  ChuanKe
//
//  Created by tarena on 15/8/6.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZQMineViewController : UIViewController

@property (nonatomic, strong) UITableView *tableView;


@end
