//
//  ZQSearchViewController.h
//  ChuanKe
//
//  Created by tarena on 15/8/11.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZQSearchViewController : UIViewController

@property (nonatomic, strong) UITextField *textFiled;
@property (nonatomic, strong) UITableView *tableView;

@end
