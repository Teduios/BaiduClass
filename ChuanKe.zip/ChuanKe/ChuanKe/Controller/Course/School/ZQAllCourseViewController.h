//
//  ZQAllCourseViewController.h
//  ChuanKe
//
//  Created by tarena on 15/8/9.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZQAllCourseViewController : UIViewController

@property(nonatomic, strong) NSString *DO;/**< 用来表示查询的是直播课程(prelectList)，或者是所有非直播课程(courseList) */
@property(nonatomic, strong) NSString *SID;/**< 学校ID */

@property(nonatomic, strong) UITableView *tableView;

@end
