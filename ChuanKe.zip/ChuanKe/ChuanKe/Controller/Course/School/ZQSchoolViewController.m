//
//  ZQSchoolViewController.m
//  ChuanKe
//
//  Created by tarena on 15/8/9.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQSchoolViewController.h"
#import "NetWorkSingleton.h"
#import "MJExtension.h"
#import "ZQSchoolModel.h"
#import "ZQTeacherModel.h"
#import "ZQSchoolCell.h"
#import "NSString+Size.h"
#import "UIImageView+WebCache.h"
#import "ZQAllCourseViewController.h"
#import "ZQInfoViewController.h"
#import "UMSocial.h"

@interface ZQSchoolViewController ()<UITableViewDataSource,UITableViewDelegate,ZQSchoolDelegate>
{
    ZQSchoolModel *_schoolModel;
    ZQTeacherModel *_teacherModel;
    NSMutableArray *_teachersArray;
}

@end

@implementation ZQSchoolViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self setNavi];
    [self initTableView];
    
    //接受数据
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self getSchoolData];
    });
}

- (void)setNavi {
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_width, 64)];
    backView.backgroundColor = navigationBarColor;
    [self.view addSubview:backView];
    //返回按钮
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    backButton.frame = CGRectMake(0, 20, 40, 40);
    [backButton setImage:[UIImage imageNamed:@"file_tital_back_but"] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(onTapBack:) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:backButton];
    //标题
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 20, 120, 40)];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.text = @"学校详情";
    [backView addSubview:titleLabel];
    //收藏
    UIButton *collectBtn = [UIButton buttonWithType: UIButtonTypeCustom];
    collectBtn.frame = CGRectMake(screen_width-40, 20, 40, 40);
    [collectBtn setImage:[UIImage imageNamed:@"course_info_bg_collect"] forState:UIControlStateNormal];
    [collectBtn setImage:[UIImage imageNamed:@"course_info_bg_collected"] forState:UIControlStateSelected];
    [collectBtn addTarget:self action:@selector(onTapCollect:) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:collectBtn];
}

- (void)initTableView {
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, screen_width, screen_height - 64) style:UITableViewStyleGrouped];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:self.tableView];
}

- (void)getSchoolData {
    NSString *urlStr = [NSString stringWithFormat:@"http://pop.client.chuanke.com/?mod=school&act=info&mode=&sid=%@&uid=%@",self.SID,UID];
     NSLog(@"学校--------%@",urlStr);
    [[NetWorkSingleton sharedManger] getDataResult:nil url:urlStr successBlock:^(id responseBody) {
        NSLog(@"请求学校数据成功");
        _schoolModel = [ZQSchoolModel objectWithKeyValues:responseBody];
        _teachersArray = [NSMutableArray array];
        for (NSDictionary *teacherDic in _schoolModel.TeacherList) {
            _teacherModel = [ZQTeacherModel objectWithKeyValues:teacherDic];
            [_teachersArray addObject:_teacherModel];
        }
        [self.tableView reloadData];
    } failureBlock:^(NSString *error) {
        NSLog(@"请求学校数据失败%@",error);
    }];
}

#pragma mark -- UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (_schoolModel != nil) {
        return 4;
    }
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 1;
    }else if (section == 1) {
        return 1;
    }else if (section == 2) {
        //最多显示三行老师信息
        if (_teachersArray.count > 3) {
            return 5;
        }else {
            return 1 + _teachersArray.count;
        }
    }else {
        return 2;
    }
}
//表头高
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 0.1;
}
//表尾高
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 10;
}
//行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return 266;
    }else if (indexPath.section == 1) {
        CGSize lableSize = [_schoolModel.Notice boundingRectWithSize:CGSizeMake(screen_width-20, 0) withFont:13];
        return lableSize.height + 10;
    }else if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            return 40;
        }else if (indexPath.row == 4) {
        //更多
            return 30;
        }else {
            return 70;
        }
    }else {
        if (indexPath.row == 0) {
            CGSize labelSize = [_schoolModel.Brief boundingRectWithSize:CGSizeMake(screen_width-20, 0) withFont:13];
            return labelSize.height + 30 + 10;
        }else {
        //更多
            return 30;
        }
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        static NSString *cellId = @"schoolCell";
        ZQSchoolCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
        if (!cell) {
            cell = [[ZQSchoolCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        }
        if (_schoolModel != nil) {
            [cell setSchoolModel:_schoolModel];
        }
        //设置代理
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }else if (indexPath.section == 1) {
        static NSString *cellId = @"noticeCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
            UILabel *noticeLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, screen_width-20, 20)];
            //加tag
            noticeLabel.tag = 50;
            noticeLabel.textColor = [UIColor lightGrayColor];
            noticeLabel.font = [UIFont systemFontOfSize:13];
            noticeLabel.numberOfLines = 0;
            [cell addSubview:noticeLabel];
        }
        CGSize labelSize = [_schoolModel.Notice boundingRectWithSize:CGSizeMake(screen_width-20, 0) withFont:13];
        UILabel *noticeLabel = (UILabel *)[cell viewWithTag:50];
        noticeLabel.text = _schoolModel.Notice;
        noticeLabel.frame = CGRectMake(10, 5, screen_width-20, labelSize.height);
        return cell;
    }else if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            static NSString *cellId = @"teacherTitleCell";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
            }
            cell.textLabel.text = @"学校老师";
            return cell;
        }else if (indexPath.row == 4) {
            static NSString *cellId = @"moreCell";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellId];
            }
            cell.detailTextLabel.text = @"更多";
            cell.detailTextLabel.font = [UIFont systemFontOfSize:13];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            return cell;
        }else {
            //老师
            static NSString *cellId = @"teacherCell";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
                //头像
                UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 50, 50)];
                imageView.layer.masksToBounds = YES;
                imageView.layer.cornerRadius = 25;
                imageView.tag = 51;
                [cell addSubview:imageView];
                //昵称
                UILabel *nickNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(70, 5, screen_width-10-70, 30)];
                nickNameLabel.textColor = navigationBarColor;
                nickNameLabel.font = [UIFont systemFontOfSize:15];
                nickNameLabel.tag = 52;
                [cell addSubview:nickNameLabel];
                //说说
                UILabel *briefLabel = [[UILabel alloc] initWithFrame:CGRectMake(nickNameLabel.frame.origin.x, CGRectGetMaxY(nickNameLabel.frame)+5, nickNameLabel.frame.size.width, nickNameLabel.frame.size.height)];
                briefLabel.textColor = [UIColor lightGrayColor];
                briefLabel.font = [UIFont systemFontOfSize:13];
                briefLabel.tag = 53;
                [cell addSubview:briefLabel];
            }
            UIImageView *imageView = (UIImageView *)[cell viewWithTag:51];
            UILabel *nickNameLabel = (UILabel *)[cell viewWithTag:52];
            UILabel *briefLabel = (UILabel *)[cell viewWithTag:53];
            ZQTeacherModel *teacherModel = _teachersArray[indexPath.row-1];
            nickNameLabel.text = teacherModel.TeacherName;
            briefLabel.text = teacherModel.Brief;
            [imageView sd_setImageWithURL:[NSURL URLWithString:teacherModel.Avatar] placeholderImage:[UIImage imageNamed:@"lesson_default"]];
            return cell;
        }
    //学校介绍
    }else {
        if (indexPath.row == 0) {
            static NSString *cellId = @"schoolTitleCell";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
                //学校介绍
                UILabel *schoolInfoLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, 100, 25)];
                schoolInfoLabel.text = @"学校介绍";
                [cell addSubview:schoolInfoLabel];
                //内容
                UILabel *briefLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 35, screen_width-20, 20)];
                briefLabel.font = [UIFont systemFontOfSize:13];
                briefLabel.textColor = [UIColor lightGrayColor];
                briefLabel.numberOfLines = 0;
                briefLabel.tag = 60;
                [cell addSubview:briefLabel];
            }
            CGSize labelSize = [_schoolModel.Brief boundingRectWithSize:CGSizeMake(screen_width-20, 0) withFont:13];
            UILabel *briefLabel = (UILabel *)[cell viewWithTag:60];
            briefLabel.text = _schoolModel.HtmlBrief;
            briefLabel.frame = CGRectMake(10, 35, screen_width-20, labelSize.height);
            return cell;
        }else {
            static NSString *cellId = @"schoolMoreCell";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellId];
            }
            cell.detailTextLabel.text = @"更多";
            cell.detailTextLabel.font = [UIFont systemFontOfSize:13];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            return cell;
        }
    }
}

#pragma mark -- UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 3 && indexPath.row == 1) {
        ZQInfoViewController *vc = [[ZQInfoViewController alloc] init];
        vc.titleName = @"学校介绍";
        vc.Brief = _schoolModel.HtmlBrief;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

#pragma mark -- ZQSchoolDelegate
- (void)didSelectedAtIndex:(NSInteger)index {
    ZQAllCourseViewController *vc = [[ZQAllCourseViewController alloc] init];
    vc.SID = self.SID;
    if (index == 0) {
        vc.DO = @"courseList";
        [self.navigationController pushViewController:vc animated:YES];
    }else if (index == 1) {//直播
        vc.DO = @"prelectList";
        [self.navigationController pushViewController:vc animated:YES];
    }else if (index == 2) {
        [UMSocialSnsService presentSnsIconSheetView:self appKey:UMAPPKEY shareText:_schoolModel.SchoolName shareImage:[UIImage imageNamed:@"school_pic1"] shareToSnsNames:@[UMShareToWechatSession,UMShareToWechatTimeline,UMShareToSina,UMShareToQQ] delegate:nil];
    }
}

#pragma onTapButton
- (void)onTapBack:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)onTapCollect:(UIButton *)sender {
    NSLog(@"收藏");
    [UMSocialSnsService presentSnsIconSheetView:self appKey:UMAPPKEY shareText:_schoolModel.SchoolName shareImage:[UIImage imageNamed:@"school_pic1"] shareToSnsNames:@[UMShareToWechatSession,UMShareToWechatTimeline,UMShareToSina,UMShareToQQ] delegate:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
