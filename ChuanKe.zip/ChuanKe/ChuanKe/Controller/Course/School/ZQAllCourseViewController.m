//
//  ZQAllCourseViewController.m
//  ChuanKe
//
//  Created by tarena on 15/8/9.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQAllCourseViewController.h"
#import "NetWorkSingleton.h"
#import "ZQAllCourseModel.h"
#import "MJExtension.h"
#import "ZQAllCourseCell.h"
#import "ZQCourseDetailViewController.h"

@interface ZQAllCourseViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *_dataSourceArray;
}

@end

@implementation ZQAllCourseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    self.view.backgroundColor = [UIColor whiteColor];
    
    _dataSourceArray = [[NSMutableArray alloc] init];
    
    [self setNavi];
    [self initTableView];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self getAllCourseData];
    });
}

- (void)setNavi {
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_width, 64)];
    backView.backgroundColor = navigationBarColor;
    [self.view addSubview:backView];
    //返回按钮
    UIButton *backBtn = [UIButton buttonWithType: UIButtonTypeCustom];
    backBtn.frame = CGRectMake(0, 20, 40, 40);
    [backBtn setImage:[UIImage imageNamed:@"file_tital_back_but"] forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(onTapBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:backBtn];
    
    //标题
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(screen_width/2-60, 20, 120, 40)];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.text = @"学校课程";
    [backView addSubview:titleLabel];
}

- (void)initTableView {
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, screen_width, screen_height-64) style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableView];
}

- (void)getAllCourseData {
    NSString *urlStr = [NSString stringWithFormat:@"http://pop.client.chuanke.com/?mod=school&act=info&do=%@&sid=%@&uid=%@",self.DO,self.SID,UID];
    [[NetWorkSingleton sharedManger] getDataResult:nil url:urlStr successBlock:^(id responseBody) {
        NSLog(@"请求课程列表成功");
        //Json列表是用数组保存的
        NSMutableArray *dataArray = responseBody;
        for (int i = 0; i < dataArray.count; i++) {
            ZQAllCourseModel *allCourseModel = [ZQAllCourseModel objectWithKeyValues:dataArray[i]];
            [_dataSourceArray addObject:allCourseModel];
        }
        
        [self.tableView reloadData];
    } failureBlock:^(NSString *error) {
        NSLog(@"请求课程列表失败:%@",error);
    }];
}

- (void)onTapBackBtn:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -- UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataSourceArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 74;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"allCourseCell";
    ZQAllCourseCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[ZQAllCourseCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 73.5, screen_width, 0.5)];
        lineView.backgroundColor = separaterColor;
        [cell addSubview:lineView];
    }
    ZQAllCourseModel *allCourseModel = _dataSourceArray[indexPath.row];
    [cell setAllCourseModel:allCourseModel];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

#pragma mark -- UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    ZQAllCourseModel *allCourseModel = _dataSourceArray[indexPath.row];
    ZQCourseDetailViewController *vc = [[ZQCourseDetailViewController alloc] init];
    vc.SID = self.SID;
    vc.CourseID = allCourseModel.CourseID;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
