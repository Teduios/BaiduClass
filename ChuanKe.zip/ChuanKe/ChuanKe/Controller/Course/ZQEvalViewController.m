//
//  ZQEvalViewController.m
//  ChuanKe
//
//  Created by tarena on 15/8/10.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQEvalViewController.h"
#import "NetWorkSingleton.h"
#import "ZQEvalCell.h"
#import "ZQEvalModel.h"
#import "MJExtension.h"
#import "MJRefresh.h"
#import "SVProgressHUD.h"

#define MARGIN 5

@interface ZQEvalViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSInteger _page;
    NSInteger _pageLimit;
    
    NSMutableArray *_dataSourceArray;
}

@end

@implementation ZQEvalViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    _page = 1;
    _pageLimit = 20;
    _dataSourceArray = [NSMutableArray array];
    
    [self setNavi];
    [self initTableView];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self getEvalData];
    });
    // Do any additional setup after loading the view.
}

- (void)setNavi {
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_width, 64)];
    backView.backgroundColor = navigationBarColor;
    [self.view addSubview:backView];
    //返回按钮
    UIButton *backBtn = [UIButton buttonWithType: UIButtonTypeCustom];
    backBtn.frame = CGRectMake(0, 20, 40, 40);
    [backBtn setImage:[UIImage imageNamed:@"file_tital_back_but"] forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(onTapBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:backBtn];
    
    //标题
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(screen_width/2-60, 20, 120, 40)];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.text = @"学生评价";
    [backView addSubview:titleLabel];
    
    //收藏
//    UIButton *collectBtn = [UIButton buttonWithType: UIButtonTypeCustom];
//    collectBtn.frame = CGRectMake(screen_width-50, 20, 40, 40);
//    [collectBtn setTitle:@"评价" forState:UIControlStateNormal];
//    
//    [collectBtn addTarget:self action:@selector(OnTapCollectBtn:) forControlEvents:UIControlEventTouchUpInside];
//    [backView addSubview:collectBtn];
}

- (void)initTableView {
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, screen_width, screen_height-64) style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableView];
}

- (void)getEvalData {
    NSString *urlStr = [NSString stringWithFormat:@"http://pop.client.chuanke.com/?mod=course&act=vote&do=list&uid=%@&courseid=%@&sid=%@&limit=%ld&page=%ld",UID,self.courseID,self.SID,_pageLimit,_page];
    NSLog(@"评论--------%@",urlStr);
    [[NetWorkSingleton sharedManger] getClassEvalResult:nil url:urlStr successBlock:^(id responseBody) {
        NSLog(@"请求评论成功");
        //取出数据列表
        NSMutableArray *dataListArray = [responseBody objectForKey:@"DataList"];
        if (_page == 1) {
            [_dataSourceArray removeAllObjects];
        }
        
        for (int i = 0; i < dataListArray.count; i++) {
            ZQEvalModel *evalModel = [ZQEvalModel objectWithKeyValues:dataListArray[i]];
            [_dataSourceArray addObject:evalModel];
        }
        [self.tableView reloadData];
    } failureBlock:^(NSString *error) {
        [SVProgressHUD showErrorWithStatus:error];
        NSLog(@"请求评论失败:%@",error);
    }];
}

- (void)onTapBackBtn:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -- UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataSourceArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    ZQEvalModel *evalModel = _dataSourceArray[indexPath.row];
    return 10+20+MARGIN+evalModel.voteTextHeight+MARGIN+20+MARGIN;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"evalCell";
    ZQEvalCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[ZQEvalCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    if (_dataSourceArray.count) {
        ZQEvalModel *evalModel = _dataSourceArray[indexPath.row];
        [cell setEvalModel:evalModel];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    cell.layer.transform = CATransform3DMakeScale(0.1, 0.1, 1);
    [UIView animateWithDuration:0.25 animations:^{
        cell.layer.transform = CATransform3DMakeScale(1, 1, 1);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
