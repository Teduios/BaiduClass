
//
//  ZQSearchViewController.m
//  ChuanKe
//
//  Created by tarena on 15/8/11.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQSearchViewController.h"
#import "NetWorkSingleton.h"
#import "ZQCategoryModel.h"
#import "ZQAllCourseCell.h"
#import "MJExtension.h"
#import "SVProgressHUD.h"
#import "ZQCourseDetailViewController.h"

@interface ZQSearchViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSString *_resultStr;
    UITapGestureRecognizer *_tap;
    NSMutableArray *_dataSourceArray;
}

@end

@implementation ZQSearchViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addTap:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(moveTap:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)addTap:(NSNotification *)notification {
    _tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyBoard:)];
    [self.view addGestureRecognizer:_tap];
}

- (void)moveTap:(NSNotification *)notification {
    [self.view removeGestureRecognizer:_tap];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self initData];
    [self setNavi];
    [self initViews];
    [self initTableView];
}

- (void)initData {
    _dataSourceArray = [NSMutableArray array];
}

- (void)setNavi {
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_width, 64)];
    backView.backgroundColor = navigationBarColor;
    [self.view addSubview:backView];
    
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    backButton.frame = CGRectMake(0, 20, 40, 40);
    [backButton setImage:[UIImage imageNamed:@"file_tital_back_but"] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(clickBackButton) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:backButton];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(screen_width/2-60, 20, 120, 40)];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.text = @"搜索课程";
    [backView addSubview:titleLabel];
    
    UIButton *searchBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    searchBtn.frame = CGRectMake(screen_width-60, 20, 40, 40);
    searchBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [searchBtn setTitle:@"搜索" forState:UIControlStateNormal];
    [searchBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [searchBtn addTarget:self action:@selector(clickSearchBtn) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:searchBtn];
}

- (void)initViews {
    //搜索框
    self.textFiled = [[UITextField alloc] initWithFrame:CGRectMake(10, 64+10, screen_width-20, 30)];
    self.textFiled.clearButtonMode = UITextFieldViewModeAlways;
    self.textFiled.placeholder = @"请输入搜索课程^_^";
    self.textFiled.text = @"";
    self.textFiled.backgroundColor = RGB(242, 242, 242);
    self.textFiled.font = [UIFont systemFontOfSize:14];
    self.textFiled.borderStyle = UITextBorderStyleRoundedRect;
    [self.view addSubview:self.textFiled];

}

- (void)initTableView {
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64+40, screen_width, screen_height-104)];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableView];
}

- (void)getData {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self getSearchData];
    });
}

- (void)getSearchData {
    NSString *urlStr = [NSString stringWithFormat:@"http://pop.client.chuanke.com/?mod=search&act=mobile&page=1&limit=20&keyword=%@&cVersion=2.4.1.2&from=iPhone",self.textFiled.text];
    NSLog(@"搜索请求url---%@",urlStr);
    [[NetWorkSingleton sharedManger] getSearchResult:nil url:urlStr successBlock:^(id responseBody) {
        NSLog(@"搜索请求成功");
        [_dataSourceArray removeAllObjects];
        NSMutableArray *classListArray = [responseBody objectForKey:@"ClassList"];
        for (int i = 0; i < classListArray.count; i++) {
            ZQCategoryModel *categoryModel = [ZQCategoryModel objectWithKeyValues:classListArray[i]];
            [_dataSourceArray addObject:categoryModel];
        }
        [self.tableView reloadData];
        [self.view endEditing:YES];
    } failureBlock:^(NSString *error) {
        [SVProgressHUD showErrorWithStatus:error];
        NSLog(@"搜索请求失败");
    }];
}


- (void)hideKeyBoard:(UITapGestureRecognizer *)sender {
    [self.view endEditing:YES];
}

- (void)clickBackButton {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)clickSearchBtn {
    if ([self.textFiled.text isEqualToString:@""]) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"请输入内容再搜索" delegate:self cancelButtonTitle:@"好的" otherButtonTitles:nil,nil];
        [alertView show];
        return;
    }
    [self getData];
}

#pragma mark -- UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataSourceArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 74;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"searchCell";
    ZQAllCourseCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[ZQAllCourseCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 73.5, screen_width, 0.5)];
        lineView.backgroundColor = separaterColor;
        [cell addSubview:lineView];
    }
    ZQCategoryModel *categoryModel = _dataSourceArray[indexPath.row];
    [cell setCategoryModel:categoryModel];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

#pragma mark -- UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"%ld",indexPath.row);
    ZQCategoryModel *categoryModel = _dataSourceArray[indexPath.row];
    ZQCourseDetailViewController *vc = [[ZQCourseDetailViewController alloc] init];
    vc.SID = categoryModel.SID;
    vc.CourseID = categoryModel.CourseID;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
