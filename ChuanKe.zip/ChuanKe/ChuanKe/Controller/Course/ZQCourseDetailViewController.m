//
//  ZQCourseDetailViewController.m
//  ChuanKe
//
//  Created by tarena on 15/8/7.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQCourseDetailViewController.h"
#import "NetWorkSingleton.h"
#import "MJExtension.h"
#import "MJRefresh.h"
#import "SVProgressHUD.h"
#import "UMSocial.h"

#import "ZQStepListModel.h"
#import "ZQClassListModel.h"
#import "ZQCourseDetailInfoCell.h"
#import "ZQCourseClassCell.h"
#import "ZQCourseViewController.h"
#import "ZQSchoolViewController.h"
#import "ZQInfoViewController.h"
#import "ZQEvalViewController.h"
#import "VedioDetailViewController.h"

@interface ZQCourseDetailViewController ()<UITableViewDataSource,UITableViewDelegate,ZQCourseDetailInfoDelegate>
{
    ZQCourseDetailModel *_courseDetailModel;
    NSMutableArray *_dataSourceArray;//课表数据
    UIView *_headerView;
}

@end

@implementation ZQCourseDetailViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        //隐藏tabbar
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self initData];
    [self setNavi];
    [self initTableView];
}

- (void)initData {
    _dataSourceArray = [NSMutableArray array];
}

- (void)setNavi {
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_width, 64)];
    backView.backgroundColor = navigationBarColor;
    [self.view addSubview:backView];
    
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    backButton.frame = CGRectMake(0, 20, 40, 40);
    [backButton setImage:[UIImage imageNamed:@"file_tital_back_but"] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(onTapBackButton:) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:backButton];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(screen_width/2-60, 20, 120, 40)];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.text = @"课程详情";
    [backView addSubview:titleLabel];
    
    UIButton *collectBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    collectBtn.frame = CGRectMake(screen_width-40, 20, 40, 40);
    [collectBtn setImage:[UIImage imageNamed:@"course_info_bg_collect"] forState:UIControlStateNormal];
    [collectBtn setImage:[UIImage imageNamed:@"course_info_bg_collected"] forState:UIControlStateSelected];
    [collectBtn addTarget:self action:@selector(onTapCollectBtn:) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:collectBtn];
}

- (void)initTableView {
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, screen_width, screen_height - 64) style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableView];
    
    [self setUpTableView];
}

- (void)setUpTableView {
    [self.tableView addGifHeaderWithRefreshingTarget:self refreshingAction:@selector(loadNewData)];
    
    NSMutableArray *idelImages = [NSMutableArray array];
    for (int i = 0; i < 60; ++i) {
        UIImage *image = [UIImage imageNamed:@"icon_listheader_animation_1"];
        [idelImages addObject:image];
    }
    [self.tableView.gifHeader setImages:idelImages forState:MJRefreshHeaderStateIdle];
    
    NSMutableArray *refrechImages = [NSMutableArray array];
    UIImage *image1 = [UIImage imageNamed:@"icon_listheader_animation_1"];
    UIImage *image2 = [UIImage imageNamed:@"icon_listheader_animation_2"];
    [refrechImages addObject:image1];
    [refrechImages addObject:image2];
    [self.tableView.gifHeader setImages:refrechImages forState:MJRefreshHeaderStatePulling];
    
    [self.tableView.gifHeader setImages:refrechImages forState:MJRefreshHeaderStateRefreshing];
    
    [self.tableView.gifHeader beginRefreshing];
}

- (void)loadNewData {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self getClassListData];
    });
}

- (void)getClassListData {
    NSString *urlStr = [NSString stringWithFormat:@"http://pop.client.chuanke.com/?mod=course&act=info&do=getClassList&sid=%@&courseid=%@&version=%@&uid=%@",self.SID,self.CourseID,VERSION,UID];
    NSLog(@"请求课程详情:%@",urlStr);
    [[NetWorkSingleton sharedManger] getClassEvalResult:nil url:urlStr successBlock:^(id responseBody) {
        NSLog(@"获取课程列表成功");
        _courseDetailModel = [ZQCourseDetailModel objectWithKeyValues:responseBody];
        [_dataSourceArray removeAllObjects];
        //存数据
        for (int i = 0; i < _courseDetailModel.StepList.count; i++) {
            ZQStepListModel *stepModel = [ZQStepListModel objectWithKeyValues:_courseDetailModel.StepList[i]];
            [_dataSourceArray addObject:stepModel];
            for (int j = 0; j < stepModel.ClassList.count; j++) {
                ZQClassListModel *classModel = [ZQClassListModel objectWithKeyValues:stepModel.ClassList[j]];
                if (j == stepModel.ClassList.count - 1) {
                    classModel.isLast = @"1";
                }else {
                    classModel.isLast = @"0";
                }
                classModel.index = [NSString stringWithFormat:@"%d",j+1];
                [_dataSourceArray addObject:classModel];
            }
        }
        
        [self.tableView reloadData];
        [self.tableView.header endRefreshing];
    } failureBlock:^(NSString *error) {
        [SVProgressHUD showErrorWithStatus:error];
        NSLog(@"获取课程列表失败:%@",error);
        [self.tableView.header endRefreshing];
    }];
}

#pragma mark -- OnTapButton
- (void)onTapBackButton:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)onTapCollectBtn:(UIButton *)sender {
    [UMSocialSnsService presentSnsIconSheetView:self appKey:UMAPPKEY shareText:_courseDetailModel.CourseName shareImage:[UIImage imageNamed:@"school_pic1"] shareToSnsNames:@[UMShareToWechatSession,UMShareToWechatTimeline,UMShareToSina,UMShareToQQ] delegate:nil];
}

#pragma mark -- UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (_courseDetailModel != nil) {
        return 2;
    }
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 1;
    }else {
        return _dataSourceArray.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        static NSString *cellId = @"detailCell";
        ZQCourseDetailInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
        if (!cell) {
            cell = [[ZQCourseDetailInfoCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        }
        if (_courseDetailModel != nil) {
            [cell setCourseDetailModel:_courseDetailModel];
        }
        //设置点击学校代理
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }else {
        //章节
        if ([_dataSourceArray[indexPath.row] isKindOfClass:[ZQStepListModel class]]) {
            static NSString *cellId = @"stepCell";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
                //下划线
                UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 42.5, screen_width, 0.5)];
                lineView.backgroundColor = separaterColor;
                [cell addSubview:lineView];
            }
            ZQStepListModel *stepModel = _dataSourceArray[indexPath.row];
            cell.textLabel.text = [NSString stringWithFormat:@"第%@章:%@",stepModel.StepIndex, stepModel.StepName];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        //每节课
        }else {
            static NSString *cellId = @"classCell";
            ZQCourseClassCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
            if (!cell) {
                cell = [[ZQCourseClassCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
                UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(40, 63.5, screen_width, 0.5)];
                //加tag标识
                lineView.tag = 10;
                lineView.backgroundColor = separaterColor;
                [cell addSubview:lineView];
            }
            ZQClassListModel *classModel = _dataSourceArray[indexPath.row];
            if ([classModel.isLast isEqualToString:@"1"]) {
                UIView *lineView = (UIView *)[cell viewWithTag:10];
                lineView.frame = CGRectMake(0, 63.5, screen_width, 0.5);
            }
            [cell setClassModel:classModel];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
    }
}

//单元表头高
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return 0.1;
    }else {
        return 55;
    }
}

//表尾高
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0;
}

//单元格高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return 110;
    }else {
        //判断是否是章节
        if ([_dataSourceArray[indexPath.row] isKindOfClass:[ZQStepListModel class]]) {
            return 43;
        }else {
            return 64;
        }
    }
}

//设置headerView
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return nil;
    }
    _headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_width, 55)];
    _headerView.backgroundColor = selectColor;
    //添加图片
    UITapGestureRecognizer *tapCatalog = [[UITapGestureRecognizer alloc] initWithTarget:self action:nil];
    UITapGestureRecognizer *tapInfo = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapInfo:)];
    UITapGestureRecognizer *tapEval = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapEval:)];
    [self initHeaderViewImage:@"course_catalog_icon" andIndex:0 andTitle:@"目录" andTap:tapCatalog];
    [self initHeaderViewImage:@"course_info_icon" andIndex:1 andTitle:@"详情" andTap:tapInfo];
    [self initHeaderViewImage:@"course_catalog_icon" andIndex:2 andTitle:[NSString stringWithFormat:@"评价(%@)",_courseDetailModel.TotalAppraise] andTap:tapEval];
    return _headerView;
}

- (void)initHeaderViewImage:(NSString *)imageName andIndex:(NSInteger)index andTitle:(NSString *)title andTap:(UITapGestureRecognizer *)tap {
    CGFloat margin = 40;
    CGFloat distance = (screen_width-margin*2-25*3)/2;
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(margin + index * (25 + distance) , 5, 25, 25)];
    [imageView setImage:[UIImage imageNamed:imageName]];
    [_headerView addSubview:imageView];
    imageView.userInteractionEnabled = YES;
    //手势不能传空!!!
    [imageView addGestureRecognizer:tap];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(index * ((screen_width-2*margin)/3+margin), CGRectGetMaxY(imageView.frame), (screen_width-2*margin)/3, 20)];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor whiteColor];
    label.font = [UIFont systemFontOfSize:13];
    label.text = title;
    [_headerView addSubview:label];
}

#pragma mark -- UITableViewDelegete
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([_dataSourceArray[indexPath.row] isKindOfClass:[ZQClassListModel class]]) {
        ZQClassListModel *classModel = _dataSourceArray[indexPath.row];
        if (classModel.VideoUrl == nil) {
            [SVProgressHUD showErrorWithStatus:@"当前视频暂时没有"];
            return;
        }
        NSString *fileUrl = [classModel.VideoUrl[0] objectForKey:@"FileURL"];
        NSLog(@"视频地址%@",fileUrl);
        VedioDetailViewController *vc = [[VedioDetailViewController alloc] init];
        vc.FileUrl = fileUrl;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

#pragma mark --  UITapGestureRecognizer
- (void)onTapInfo:(UITapGestureRecognizer *)sender {
    NSLog(@"点击详情");
    ZQInfoViewController *vc = [[ZQInfoViewController alloc] init];
    vc.Brief = _courseDetailModel.Brief;
    vc.titleName = @"课程详情";
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)onTapEval:(UITapGestureRecognizer *)sender {
    NSLog(@"点击评论");
    ZQEvalViewController *vc = [[ZQEvalViewController alloc] init];
    vc.SID = _courseDetailModel.SID;
    vc.courseID = _courseDetailModel.CourseID;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark -- ZQCourseDetailInfoDelegate
- (void)didSelsctedSchool {
    NSLog(@"点击学校");
    ZQSchoolViewController *vc = [[ZQSchoolViewController alloc] init];
    vc.SID = _courseDetailModel.SID;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
