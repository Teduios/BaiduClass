
//
//  ZQCategoryViewController.m
//  ChuanKe
//
//  Created by tarena on 15/8/10.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQCategoryViewController.h"
#import "NetWorkSingleton.h"
#import "ZQCategoryModel.h"
#import "ZQAllCourseCell.h"
#import "MJExtension.h"
#import "MJRefresh.h"
#import "ZQCourseDetailViewController.h"

@interface ZQCategoryViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSInteger _type;/**< segment */
    
    NSInteger _page;/**< 页数 */
    NSInteger _limit;/**< 每页的个数 */
    NSInteger _charge;/**< 1：免费；2：收费 */
    
    NSString *_cateid;/**< 课程分类ID */
    
    NSMutableArray *_dataSourceArray;
    
    UIView *_lineView;
    NSInteger _currentIndex;/**< 记录当前课程分类按钮的下标 */
}

@end

@implementation ZQCategoryViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self initData];
    [self setNavi];
    [self initViews];
    // Do any additional setup after loading the view.
}

- (void)initData {
    _dataSourceArray = [NSMutableArray array];
    _page = 1;
    _limit = 20;
    _charge = 1;
    _currentIndex = 0;
    if ([self.cateType isEqualToString:@"feizhibo"]) {
        _cateid = self.cateIDArray[0];
    }
}

- (void)setNavi {
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_width, 64)];
    backView.backgroundColor = navigationBarColor;
    [self.view addSubview:backView];
    
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(0, 20, 40, 40);
    [backBtn setImage:[UIImage imageNamed:@"file_tital_back_but"] forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(onTapBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:backBtn];
    //分类栏
    NSArray *segmentArray = @[@"免费",@"收费"];
    UISegmentedControl *segment = [[UISegmentedControl alloc] initWithItems:segmentArray];
    segment.frame = CGRectMake(screen_width/2-80, 30, 160, 30);
    segment.selectedSegmentIndex = 0;
    NSDictionary *attributes = @{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:[UIColor whiteColor]};
    [segment setTitleTextAttributes:attributes forState:UIControlStateNormal];
    NSDictionary *hlAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};
    [segment setTitleTextAttributes:hlAttributes forState:UIControlStateHighlighted];
    segment.tintColor = RGB(46, 158, 138);
    [segment addTarget:self action:@selector(onTapSegment:) forControlEvents:UIControlEventValueChanged];
    [backView addSubview:segment];
}

- (void)initViews {
    if ([self.cateType isEqualToString:@"zhibo"]) {
        self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, screen_width, screen_height-64) style:UITableViewStylePlain];
        self.tableView.dataSource = self;
        self.tableView.delegate = self;
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self.view addSubview:self.tableView];
    }else {
        //分类滚动按钮
        UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 64, screen_width, 40)];
        scrollView.alwaysBounceHorizontal = YES;
        scrollView.showsHorizontalScrollIndicator = NO;
        scrollView.showsVerticalScrollIndicator = NO;
        scrollView.backgroundColor = RGB(246, 246, 246);
        [self.view addSubview:scrollView];
        
        float buttonWidth = 60;
        //添加按钮
        for (int i = 0; i < self.cateNameArray.count; i++) {
            UIButton *cateNameBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            cateNameBtn.frame = CGRectMake(buttonWidth*i, 0, buttonWidth, 40);
            cateNameBtn.tag = 100 + i;
            //改变字体大小
            cateNameBtn.titleLabel.font = [UIFont systemFontOfSize:13];
            [cateNameBtn setTitle:self.cateNameArray[i] forState:UIControlStateNormal];
            [cateNameBtn setTitleColor:navigationBarColor forState:UIControlStateSelected];
            [cateNameBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            [cateNameBtn addTarget:self action:@selector(onTapCateBtn:) forControlEvents:UIControlEventTouchUpInside];
            [scrollView addSubview:cateNameBtn];
            if (i == 0) {
                _lineView = [[UIView alloc] initWithFrame:CGRectMake(cateNameBtn.center.x-20, 38, 40, 2)];
                _lineView.backgroundColor = navigationBarColor;
                [scrollView addSubview:_lineView];
            }
        }
        scrollView.contentSize = CGSizeMake(self.cateNameArray.count*buttonWidth, 40);
        //
        self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64+40, screen_width, screen_height-64-40) style:UITableViewStylePlain];
        self.tableView.dataSource = self;
        self.tableView.delegate = self;
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self.view addSubview:self.tableView];
    }
    [self setUpTableView];
}

- (void)setUpTableView {
    //下拉刷新
    [self.tableView addGifHeaderWithRefreshingTarget:self refreshingAction:@selector(loadnewData)];
    
    //设置普通状态的动画图片
    NSMutableArray *idleImages = [NSMutableArray array];
    for (NSUInteger i = 1; i < 60; ++i) {
        UIImage *image = [UIImage imageNamed:@"icon_listheader_animation_1"];
        [idleImages addObject:image];
    }
    [self.tableView.gifHeader setImages:idleImages forState:MJRefreshHeaderStateIdle];
    
    //设置即将刷新状态的动画图片
    NSMutableArray *refreshingImages = [NSMutableArray array];
    UIImage *image1 = [UIImage imageNamed:@"icon_listheader_animation_1"];
    [refreshingImages addObject:image1];
    UIImage *image2 = [UIImage imageNamed:@"icon_listheader_animation_2"];
    [refreshingImages addObject:image2];
    [self.tableView.gifHeader setImages:refreshingImages forState:MJRefreshHeaderStatePulling];
    
    //设置正在刷新是的动画图片
    [self.tableView.gifHeader setImages:refreshingImages forState:MJRefreshHeaderStateRefreshing];
    
    //马上进入刷新状态
    [self.tableView.gifHeader beginRefreshing];
    
    //上拉刷新
    [self.tableView addGifFooterWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
    
    //设置正在刷新的动画
    self.tableView.gifFooter.refreshingImages = refreshingImages;
}

- (void)onTapBackBtn:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)onTapSegment:(UISegmentedControl *)sender {
    NSInteger index = sender.selectedSegmentIndex;
    if (index == 0) {
        NSLog(@"点击免费");
        _page = 1;
        _charge = 1;
    }else {
        NSLog(@"点击收费");
        _page = 1;
        _charge = 2;
    }
    //开始刷新
    [self.tableView.gifHeader beginRefreshing];
}

- (void)onTapCateBtn:(UIButton *)sender {
    NSInteger index = sender.tag - 100;
    _currentIndex = index;
    _cateid = _cateIDArray[index];
    _page = 1;
    [UIView animateWithDuration:0.5 animations:^{
        _lineView.center = CGPointMake(sender.center.x, 39);
    }];
    [self.tableView.gifHeader beginRefreshing];
}

- (void)loadnewData {
    _page = 1;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self getAllCourseData];
    });
}

- (void)loadMoreData {
    _page++;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self getAllCourseData];
    });
}

//非直播：http://pop.client.chuanke.com/?mod=search&act=mobile&from=iPhone&page=1&limit=20&cateid=72351176527446016&charge=1
//直播：http://pop.client.chuanke.com/?mod=search&act=mobile&from=iPhone&page=1&limit=20&today=1&charge=1
- (void)getAllCourseData {
    NSString *urlStr = nil;
    if ([self.cateType isEqualToString:@"zhibo"]) {
        urlStr = [NSString stringWithFormat:@"http://pop.client.chuanke.com/?mod=search&act=mobile&from=iPhone&page=%ld&limit=%ld&today=1&charge=%ld",_page,_limit,_charge];
    }else{
        urlStr = [NSString stringWithFormat:@"http://pop.client.chuanke.com/?mod=search&act=mobile&from=iPhone&page=%ld&limit=%ld&cateid=%@&charge=%ld",_page,_limit,_cateid,_charge];
    }
    NSLog(@"urlStr:%@",urlStr);
    [[NetWorkSingleton sharedManger] getDataResult:nil url:urlStr successBlock:^(id responseBody) {
        NSLog(@"请求全部课程成功");
        if (_page == 1) {
            [_dataSourceArray removeAllObjects];
        }
        //取出课程列表
        NSMutableArray *classListArray = [responseBody objectForKey:@"ClassList"];
        for (int i = 0; i < classListArray.count; i++) {
            ZQCategoryModel *categoryModel = [ZQCategoryModel objectWithKeyValues:classListArray[i]];
            [_dataSourceArray addObject:categoryModel];
        }
        //结束刷新
        [self.tableView reloadData];
        [self.tableView.header endRefreshing];
        [self.tableView.footer endRefreshing];
    } failureBlock:^(NSString *error) {
        NSLog(@"请求全部课程失败%@",error);
        [self.tableView.header endRefreshing];
        [self.tableView.footer endRefreshing];
    }];
}

#pragma mark - UITableViewDataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSourceArray.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 74;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"allcourseCell";
    ZQAllCourseCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[ZQAllCourseCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        //下划线
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 73.5, screen_width, 0.5)];
        lineView.backgroundColor = separaterColor;
        [cell addSubview:lineView];
    }
    ZQCategoryModel *categoryModel = _dataSourceArray[indexPath.row];
    [cell setCategoryModel:categoryModel];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

#pragma mark - UITableViewDelegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    ZQCategoryModel *categoryModel = _dataSourceArray[indexPath.row];
    ZQCourseDetailViewController *vc = [[ZQCourseDetailViewController alloc] init];
    vc.SID = categoryModel.SID;
    vc.CourseID = categoryModel.CourseID;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
