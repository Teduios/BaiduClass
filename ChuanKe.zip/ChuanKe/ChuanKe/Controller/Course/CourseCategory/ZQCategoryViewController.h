//
//  ZQCategoryViewController.h
//  ChuanKe
//
//  Created by tarena on 15/8/10.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZQCategoryViewController : UIViewController

//直播和非直播必须传的参数
@property (nonatomic, strong) NSString *cateType;/**< 课程类型 @"zhibo";@"feizhibo"*/
//非直播必须传的参数
@property (nonatomic, strong) NSMutableArray *cateNameArray;
@property (nonatomic, strong) NSMutableArray *cateIDArray;

@property (nonatomic, strong) UITableView *tableView;

@end
