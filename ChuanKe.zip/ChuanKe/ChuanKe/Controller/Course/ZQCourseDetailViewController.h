//
//  ZQCourseDetailViewController.h
//  ChuanKe
//
//  Created by tarena on 15/8/7.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZQCourseDetailViewController : UIViewController

@property (nonatomic, strong) UITableView *tableView;
//接受参数
@property (nonatomic, strong) NSString *SID;
@property (nonatomic, strong) NSString *CourseID;

@end
