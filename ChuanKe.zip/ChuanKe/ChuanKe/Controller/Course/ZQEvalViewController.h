//
//  ZQEvalViewController.h
//  ChuanKe
//
//  Created by tarena on 15/8/10.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZQEvalViewController : UIViewController

@property (nonatomic, strong) NSString *SID;
@property (nonatomic, strong) NSString *courseID;

@property (nonatomic, strong) UITableView *tableView;

@end
