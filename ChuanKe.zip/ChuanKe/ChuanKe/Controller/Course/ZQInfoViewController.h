//
//  ZQInfoViewController.h
//  ChuanKe
//
//  Created by tarena on 15/8/10.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZQInfoViewController : UIViewController

@property (nonatomic, strong) NSString *Brief;
@property (nonatomic, strong) NSString *titleName;

@end
