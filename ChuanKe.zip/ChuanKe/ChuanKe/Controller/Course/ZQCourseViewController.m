//
//  ZQCourseViewController.m
//  ChuanKe
//
//  Created by tarena on 15/8/6.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQCourseViewController.h"
#import "NetWorkSingleton.h"
#import "MJExtension.h"
#import "MJRefresh.h"
#import "UIImageView+WebCache.h"
#import "SVProgressHUD.h"
#import "UMSocial.h"

#import "MainScrollCell.h"
#import "ZQCourseCell.h"
#import "ZQAlbumCell.h"
#import "ZQCourseDetailViewController.h"
#import "ZQCategoryModel.h"
#import "ZQCategoryViewController.h"
#import "ZQSearchViewController.h"

#import "ZQCourseListModel.h"
#import "ZQFocusListModel.h"
#import "ZQAlbumListModel.h"

@interface ZQCourseViewController ()<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate,mainScrollViewDelegate,ZQAlbumDelegate>
{
    NSMutableArray *_focusListArray;
    NSMutableArray *_focusImageUrlArr;
    NSMutableArray *_courseListArray;
    NSMutableArray *_albumListArray;
    NSMutableArray *_albumImageUrlArr;
    
    NSInteger _type;
    
    NSMutableArray *_classCategoryArr;
    NSMutableArray *_iCategoryArr;
    UIView *_backView;
}

@end

@implementation ZQCourseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self initData];
    [self setNavi];
    [self initTableView];
}

- (void)initData {
    _focusListArray = [NSMutableArray array];
    _courseListArray = [NSMutableArray array];
    _albumListArray = [NSMutableArray array];
    
    _focusImageUrlArr = [NSMutableArray array];
    _albumImageUrlArr = [NSMutableArray array];
    
    _type = 0;
    //分类plist
    NSString *categoryPlistPath = [[NSBundle mainBundle] pathForResource:@"classCategory" ofType:@"plist"];
    _classCategoryArr = [[NSMutableArray alloc] initWithContentsOfFile:categoryPlistPath];
    //子分类plist
    NSString *iCategoryPlistPath = [[NSBundle mainBundle] pathForResource:@"iCategoryList" ofType:@"plist"];
    _iCategoryArr = [[NSMutableArray alloc] initWithContentsOfFile:iCategoryPlistPath];
}

- (void)setNavi {
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_width, 98)];
    _backView = backView;
    backView.backgroundColor = navigationBarColor;
    [self.view addSubview:backView];
    
    //标题
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(screen_width/2-80, 20, 160, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.text = @"上课啦";
    titleLabel.font = [UIFont systemFontOfSize:19];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [backView addSubview:titleLabel];
    
    //搜索item
    UIButton *searchBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    searchBtn.frame = CGRectMake(screen_width-10-40, 20, 40, 40);
    [searchBtn setImage:[UIImage imageNamed:@"search_btn_unpre_bg"] forState:UIControlStateNormal];
    [searchBtn addTarget:self action:@selector(onSearchBtn:) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:searchBtn];
    
    //segment
    NSArray *segmentArray = @[@"精选推荐",@"课程分类"];
    UISegmentedControl *segmentControl = [[UISegmentedControl alloc] initWithItems:segmentArray];
    segmentControl.frame = CGRectMake(36, 64, screen_width-36*2, 30);
    segmentControl.selectedSegmentIndex = 0;
    //字体
    NSDictionary *attributes = @{NSFontAttributeName : [UIFont boldSystemFontOfSize:15], NSForegroundColorAttributeName : [UIColor whiteColor]};
    [segmentControl setTitleTextAttributes:attributes forState:UIControlStateNormal];
    NSDictionary *highLightedAttr = @{NSForegroundColorAttributeName : [UIColor whiteColor]};
    [segmentControl setTitleTextAttributes:highLightedAttr forState:UIControlStateHighlighted];
    //背景颜色
    segmentControl.tintColor = RGB(46, 158, 138);
    [segmentControl addTarget:self action:@selector(onTapSegement:) forControlEvents:UIControlEventValueChanged];
    [backView addSubview:segmentControl];
}

- (void)initTableView {
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 98, screen_width, screen_height-98-49) style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:self.tableView];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self setUpTableView];
}

#pragma mark -- setUpTableView
- (void)setUpTableView {
    //添加下拉拉动画
    //设置下拉刷新回调
    [self.tableView addGifHeaderWithRefreshingTarget:self refreshingAction:@selector(loadNewData)];
    //设置普通状态动画图片
    NSMutableArray *idelImages = [NSMutableArray array];
    for (int i = 1; i < 60; ++i) {
        UIImage *image = [UIImage imageNamed:@"icon_listheader_animation_1"];
        [idelImages addObject:image];
    }
    [self.tableView.gifHeader setImages:idelImages forState:MJRefreshHeaderStateIdle];
    //即将刷新状态
    NSMutableArray *refreshingImages = [NSMutableArray array];
    UIImage *image1 = [UIImage imageNamed:@"icon_listheader_animation_1"];
    UIImage *image2 = [UIImage imageNamed:@"icon_listheader_animation_2"];
    [refreshingImages addObject:image1];
    [refreshingImages addObject:image2];
    [self.tableView.gifHeader setImages:refreshingImages forState:MJRefreshHeaderStatePulling];
    //正在刷新
    [self.tableView.gifHeader setImages:refreshingImages forState:MJRefreshHeaderStateRefreshing];

    [self.tableView.gifHeader beginRefreshing];
}

- (void)loadNewData {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self getRecommendData];
    });
}

#pragma mark -- onSearchBtn
- (void)onSearchBtn:(UIButton *)sender {
    ZQSearchViewController *vc = [[ZQSearchViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark -- onTapSegement
- (void)onTapSegement:(UISegmentedControl *)sender {
    NSInteger index = sender.selectedSegmentIndex;
    if (index == 0) {
        _type = 0;
    }else {
        _type = 1;
        //隐藏刷新
        self.tableView.gifHeader.hidden = YES;
    }
    [self.tableView reloadData];
}

#pragma mark -- getRecommendData
- (void)getRecommendData {
    NSString *urlStr = @"http://pop.client.chuanke.com/?mod=recommend&act=mobile&client=2&limit=20";
    NSLog(@"%@",urlStr);
    [[NetWorkSingleton sharedManger] getRecommendCourseResult:nil url:urlStr successBlock:^(id responseBody) {
        NSLog(@"请求推荐课程成功");
        NSMutableArray *focusArray = responseBody[@"FocusList"];
        NSMutableArray *courseArray = responseBody[@"CourseList"];
        NSMutableArray *albumArray = responseBody[@"AlbumList"];
        
        [_focusListArray removeAllObjects];
        [_focusImageUrlArr removeAllObjects];
        [_courseListArray removeAllObjects];
        [_albumListArray removeAllObjects];
        [_albumImageUrlArr removeAllObjects];
        
        for (int i = 0; i < focusArray.count; ++i) {
            ZQFocusListModel *focusModel = [ZQFocusListModel objectWithKeyValues:focusArray[i]];
            [_focusListArray addObject:focusModel];
            [_focusImageUrlArr addObject:focusModel.PhotoURL];
        }
        for (int i = 0; i < courseArray.count; ++i) {
            ZQCourseListModel *courseModel = [ZQCourseListModel objectWithKeyValues:courseArray[i]];
            [_courseListArray addObject:courseModel];
        }
        for (int i = 0; i < albumArray.count; ++i) {
            ZQAlbumListModel *albumModel = [ZQAlbumListModel objectWithKeyValues:albumArray[i]];
            [_albumListArray addObject:albumModel];
            [_albumImageUrlArr addObject:albumModel.PhotoURL];
        }
        
        //self.tableView.hidden = NO;
        [self.tableView reloadData];
        [self.tableView.header endRefreshing];
    } failureBlock:^(NSString *error) {
        [SVProgressHUD showErrorWithStatus:error];
        NSLog(@"请求推荐课程数据失败：%@",error);
        [self.tableView.header endRefreshing];
    }];
}

#pragma mark -- UITabelViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (_type == 0) {
        if (_courseListArray.count) {
            return _courseListArray.count + 2;
        }else {
            return 0;
        }
    }else {
        return _classCategoryArr.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (_type == 0) {
        if (indexPath.row == 0) {
            static NSString *cellId = @"focusCell";
            MainScrollCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
            if (!cell) {
                cell = [[MainScrollCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId frame:CGRectMake(0, 0, screen_width, 155)];
            }
            //设置代理
            cell.imageScrollView.delegate = self;
            [cell setImageArr:_focusImageUrlArr];
            return cell;
        }else if (indexPath.row == 1) {
            static NSString *cellId = @"albumCell";
            ZQAlbumCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
            if (!cell) {
                cell = [[ZQAlbumCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId frame:CGRectMake(0, 0, screen_width, 90)];
                //下划线
                UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 89.5, screen_width, 0.5)];
                lineView.backgroundColor = separaterColor;
                [cell addSubview:lineView];
            }
            //设置代理
            cell.delegate = self;
            [cell setImageUrlArray:_albumImageUrlArr];
            return cell;
        }else {
            static NSString *cellId = @"courseCell";
            ZQCourseCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
            if (!cell) {
                cell = [[ZQCourseCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
                //下划线
                UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 71.5, screen_width, 0.5)];
                lineView.backgroundColor = separaterColor;
                [cell addSubview:lineView];
            }
            ZQCourseListModel *courseModel = _courseListArray[indexPath.row-2];
            //初始化courseCell内容
            cell.courseModel = courseModel;
            return cell;
        }
    }else {
        static NSString *cellId = @"courseClassCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
            //下划线
            UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 59.5, screen_width, 0.5)];
            lineView.backgroundColor = separaterColor;
            [cell addSubview:lineView];
            //图
            UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 40, 40)];
            imageView.tag = 1;
            [cell addSubview:imageView];
            //标题
            UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(60, 15, 100, 30)];
            titleLabel.tag = 2;
            [cell addSubview:titleLabel];
        }
        NSDictionary *dataDic = _classCategoryArr[indexPath.row];
        UIImageView *imageView = (UIImageView *)[cell viewWithTag:1];
        imageView.image = [UIImage imageNamed:dataDic[@"image"]];
        UILabel *titleLabel = (UILabel *)[cell viewWithTag:2];
        titleLabel.text = dataDic[@"title"];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        return cell;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (_type == 0) {
        if (indexPath.row == 0) {
            return 155;
        }else if (indexPath.row == 1) {
            return 90;
        }else {
            return 72;
        }
    }else {
        return 60;
    }
}

#pragma mark -- UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (_type == 0) {
        //前两行为图片cell
        ZQCourseListModel *courseListModel = _courseListArray[indexPath.row - 2];
        ZQCourseDetailViewController *detailVC = [[ZQCourseDetailViewController alloc] init];
        detailVC.SID = courseListModel.SID;
        detailVC.CourseID = courseListModel.CourseID;
        [self.navigationController pushViewController:detailVC animated:YES];
    }else {
        ZQCategoryViewController *vc = [[ZQCategoryViewController alloc] init];
        if (indexPath.row == 0) {
            vc.cateType = @"zhibo";
        }else {
            vc.cateType = @"feizhibo";
            NSDictionary *dic = _iCategoryArr[indexPath.row - 1];
            vc.cateNameArray = dic[@"categoryName"];
            vc.cateIDArray = dic[@"categoryID"];
        }
        [self.navigationController pushViewController:vc animated:YES];
    }
}

#pragma mark -- UIScrollViewDelegate
- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView {
    if (scrollView == self.tableView && _type == 0) {
        if (self.tableView.contentOffset.y > 98) {
            [UIView animateWithDuration:0.5 animations:^{
                _backView.alpha = 0;
                CGRect tableFrame = self.tableView.frame;
                tableFrame.origin.y = 0;
                tableFrame.size.height = screen_height - 49;
                self.tableView.frame = tableFrame;
            }];
        }
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == self.tableView && _type == 0) {
        if (self.tableView.contentOffset.y < 98) {
            [UIView animateWithDuration:0.5 animations:^{
                _backView.alpha = 1;
                CGRect tableFrame = self.tableView.frame;
                tableFrame.origin.y = 98;
                tableFrame.size.height = screen_height - 49 - 98;
                self.tableView.frame = tableFrame;
            }];
        }
    }
}

#pragma mark -- MainScrollViewDelegate
- (void)didSelectImageAtIndex:(NSInteger)index {
    ZQFocusListModel *focusModel = _focusListArray[index];
    ZQCourseDetailViewController *detailVC = [[ZQCourseDetailViewController alloc] init];
    detailVC.SID = focusModel.SID;
    detailVC.CourseID = focusModel.CourseID;
    [self.navigationController pushViewController:detailVC animated:YES];
}

#pragma mark -- ZQAlbumDelegate
- (void)didSelectedAlbumAtIndex:(NSInteger)index {
    ZQAlbumListModel *albumModel = _albumListArray[index];
    [UMSocialSnsService presentSnsIconSheetView:self appKey:UMAPPKEY shareText:albumModel.Title shareImage:[UIImage imageNamed:@"school_pic1"] shareToSnsNames:@[UMShareToWechatSession,UMShareToWechatTimeline,UMShareToSina,UMShareToQQ] delegate:nil];
}


@end
