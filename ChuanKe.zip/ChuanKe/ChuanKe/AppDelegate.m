//
//  AppDelegate.m
//  ChuanKe
//
//  Created by tarena on 15/8/6.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "AppDelegate.h"
#import "ZQCourseViewController.h"
#import "ZQMineViewController.h"
#import "ZQDownloadViewController.h"
#import "UITabBarItem+Category.h"
#import "UMSocial.h"
#import "UMSocialWechatHandler.h"
#import "UMSocialQQHandler.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self initRootVC];
    return YES;
}

- (void)initRootVC {
    //1.
    ZQCourseViewController *courseVC = [[ZQCourseViewController alloc] init];
    UINavigationController *courseNavi = [[UINavigationController alloc] initWithRootViewController:courseVC];
    
    ZQMineViewController *mineVC = [[ZQMineViewController alloc] init];
    UINavigationController *mineNavi = [[UINavigationController alloc] initWithRootViewController:mineVC];
    
    ZQDownloadViewController *downloadVC = [[ZQDownloadViewController alloc] init];
    UINavigationController *downloadNavi = [[UINavigationController alloc] initWithRootViewController:downloadVC];
    
    courseVC.title = @"课程推荐";
    mineVC.title = @"我的课程";
    downloadVC.title = @"离线下载";
    //2.
    NSArray *allViews = @[courseNavi,mineNavi,downloadNavi];
    //3.
    self.rootTabbarController = [[UITabBarController alloc] init];
    [self.rootTabbarController setViewControllers:allViews animated:YES];
    //4.
    self.window.rootViewController = self.rootTabbarController;
    //5.
    UITabBar *tabbar = self.rootTabbarController.tabBar;
    UITabBarItem *courseItem = [tabbar.items objectAtIndex:0];
    UITabBarItem *mineItem = [tabbar.items objectAtIndex:1];
    UITabBarItem *downloadItem = [tabbar.items objectAtIndex:2];
    
    [courseItem setImageName:@"bottom_tab1_unpre" selectedImageName:@"bottom_tab1_pre"];
    [mineItem setImageName:@"bottom_tab2_unpre" selectedImageName:@"bottom_tab2_pre"];
    [downloadItem setImageName:@"bottom_tab3_unpre" selectedImageName:@"bottom_tab3_pre"];
    //改变字体颜色
    [[UITabBarItem appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName:navigationBarColor} forState:UIControlStateSelected];
    //友盟初始化
    [UMSocialData setAppKey:UMAPPKEY];
    [UMSocialWechatHandler setWXAppId:@"wx0e3e603965a187d4" appSecret:@"299d15c8b4d1fdb218fd49a0b8eaa4e2" url:@"http://www.fityun.cn/"];
    [UMSocialQQHandler setQQWithAppId:@"100424468" appKey:@"c7394704798a158208a74ab60104f0ba" url:@"http://www.umeng.com/social"];
    //友盟初始化，对未安装QQ，微信的平台进行隐藏
    //    [UMSocialConfig hiddenNotInstallPlatforms:@[UMShareToQQ,UMShareToQzone,UMShareToWechatSession,UMShareToWechatTimeline]];
    //[UMSocialConfig hiddenNotInstallPlatforms:@[UMShareToWechatSession,UMShareToWechatTimeline]];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
