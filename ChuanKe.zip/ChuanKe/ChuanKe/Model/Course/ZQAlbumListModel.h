//
//  ZQAlbumListModel.h
//  ChuanKe
//
//  Created by tarena on 15/8/7.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZQAlbumListModel : NSObject

@property (nonatomic, strong) NSString *AlbumID;
@property (nonatomic, strong) NSString *Title;
@property (nonatomic, strong) NSString *PhotoURL;
@property (nonatomic, strong) NSString *Sort;
@property (nonatomic, strong) NSString *message;
@property (nonatomic, strong) NSString *IphoneType;
@property (nonatomic, strong) NSString *IpadType;

@end
