//
//  ZQStepListModel.h
//  ChuanKe
//
//  Created by tarena on 15/8/7.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZQStepListModel : NSObject
//课程章节
@property (nonatomic, strong) NSString *StepID;
@property (nonatomic, strong) NSString *StepIndex;
@property (nonatomic, strong) NSString *StepName;
@property (nonatomic, strong) NSMutableArray *ClassList;

@end
