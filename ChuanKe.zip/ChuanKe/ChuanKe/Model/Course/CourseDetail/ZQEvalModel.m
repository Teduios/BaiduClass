
//
//  ZQEvalModel.m
//  ChuanKe
//
//  Created by tarena on 15/8/10.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQEvalModel.h"
#import "NSString+Size.h"

@implementation ZQEvalModel

+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"_UID":@"UID"};
}

- (void)setCreateTime:(NSString *)CreateTime {
    _CreateTime = CreateTime;
    //格式化
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"yyyy-MM-dd HH:MM"];
    NSDate *time = [NSDate dateWithTimeIntervalSince1970:[CreateTime integerValue]];
    NSString *timeStr = [formatter stringFromDate:time];
    _CreateTimeToDate = timeStr;
}

- (void)setVoteText:(NSString *)VoteText {
    _VoteText = VoteText;
    CGSize labelSize = [VoteText boundingRectWithSize:CGSizeMake(screen_width-10-70, 0) withFont:13];
    _voteTextHeight = labelSize.height;
}

@end
















