


//
//  ZQSchoolCell.m
//  ChuanKe
//
//  Created by tarena on 15/8/9.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQSchoolCell.h"
#import "UIImageView+WebCache.h"

@interface ZQSchoolCell ()
{
    UIImageView *_bigImageView;
    UIImageView *_smallImageView;
    
    UIView *_backView1;
    UIView *_backView2;
    UIView *_backView3;
    UIView *_backView4;
    
    UILabel *_courseLabel;
    UILabel *_liveLabel;
}

@end

@implementation ZQSchoolCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = RGB(246, 246, 246);
        
        _bigImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 210 - screen_width, screen_width, screen_width)];
        int num = arc4random()%9+1;
        NSString *imageName = [NSString stringWithFormat:@"school_pic%d.jpg",num];
        [_bigImageView setImage:[UIImage imageNamed:imageName]];
        [self addSubview:_bigImageView];
        
        _smallImageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 210 - 30, 60, 60)];
        _smallImageView.layer.masksToBounds = YES;
        _smallImageView.layer.cornerRadius = 5;
        [self addSubview:_smallImageView];
        
        CGFloat minX = 70;
        CGFloat width = (screen_width - minX) / 4;
        //课程
        _backView1 = [[UIView alloc] initWithFrame:CGRectMake(minX, 210, width, 56)];
        //
        _courseLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, width, 30)];
        _courseLabel.textColor = [UIColor grayColor];
        _courseLabel.text = @"000";
        _courseLabel.font = [UIFont systemFontOfSize:13];
        _courseLabel.textAlignment = NSTextAlignmentCenter;
        [_backView1 addSubview:_courseLabel];
        //
        UITapGestureRecognizer *tapCourse = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapCourse)];
        [self initView:_backView1 withTitle:@"课程" andImageName:nil andTap:tapCourse isLabel:YES];
        [self addSubview:_backView1];
        //直播
        _backView2 = [[UIView alloc] initWithFrame:CGRectMake(minX + width, 210, width, 56)];
        _liveLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, width, 30)];
        _liveLabel.textColor = [UIColor grayColor];
        _liveLabel.text = @"111";
        _liveLabel.font = [UIFont systemFontOfSize:13];
        _liveLabel.textAlignment = NSTextAlignmentCenter;
        [_backView2 addSubview:_liveLabel];
        UITapGestureRecognizer *tapLive = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapLive)];
        [self initView:_backView2 withTitle:@"直播" andImageName:nil andTap:tapLive isLabel:YES];
        [self addSubview:_backView2];
        //分享
        _backView3 = [[UIView alloc] initWithFrame:CGRectMake(minX+width*2, 210, width, 56)];
        UITapGestureRecognizer *tapShare = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapShare)];
        [self initView:_backView3 withTitle:nil andImageName:@"share" andTap:tapShare isLabel:NO];
        [self addSubview:_backView3];
        //放到桌面
        _backView4 = [[UIView alloc] initWithFrame:CGRectMake(minX+width*3, 210, width, 56)];
        UITapGestureRecognizer *tapDesktop = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapDesktop)];
        [self initView:_backView4 withTitle:nil andImageName:@"desktop" andTap:tapDesktop isLabel:NO];
        [self addSubview:_backView4];
    }
    return self;
}

- (void)initView:(UIView *)view withTitle:(NSString *)title andImageName:(NSString *)imageName andTap:(UITapGestureRecognizer *)tap isLabel:(BOOL)isLabel {
    CGFloat minX = 70;
    CGFloat width = (screen_width - minX) / 4;
    if (isLabel) {
        UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 30, width, 20)];
        label1.textColor = [UIColor grayColor];
        label1.font = [UIFont systemFontOfSize:11];
        label1.text = title;
        label1.textAlignment = NSTextAlignmentCenter;
        [view addSubview:label1];
    }else {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(width/2-27, 0, 55, 55);
        [button setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@_press",imageName]] forState:UIControlStateSelected];
        [view addSubview:button];
    }
    [view addGestureRecognizer:tap];
}

- (void)setSchoolModel:(ZQSchoolModel *)schoolModel {
    _schoolModel = schoolModel;
    [_smallImageView sd_setImageWithURL:[NSURL URLWithString:_schoolModel.SchoolLogoUrl] placeholderImage:[UIImage imageNamed:@"lesson_default"]];
    _courseLabel.text = _schoolModel.CourseSaleNumber;
    _liveLabel.text = _schoolModel.PrelectNum;
}

#pragma mark -- onTapView
-(void)onTapCourse {
    [self.delegate didSelectedAtIndex:0];
    NSLog(@"00000");
}

-(void)onTapLive {
    if ([self.schoolModel.PrelectNum isEqualToString:@"0"]) {
        return;
    }
    [self.delegate didSelectedAtIndex:1];
    NSLog(@"11111");
}

-(void)onTapShare {
    [self.delegate didSelectedAtIndex:2];
    NSLog(@"22222");
}

-(void)onTapDesktop {
    [self.delegate didSelectedAtIndex:3];
    NSLog(@"33333");
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
