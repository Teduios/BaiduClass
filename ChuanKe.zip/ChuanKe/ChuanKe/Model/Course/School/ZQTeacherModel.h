//
//  ZQTeacherModel.h
//  ChuanKe
//
//  Created by tarena on 15/8/9.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZQTeacherModel : NSObject
//与宏重复要重写replacedKeyFromPropertyName
@property (nonatomic, strong) NSString *_UID;
@property (nonatomic, strong) NSString *TeacherName;
@property (nonatomic, strong) NSString *Brief;
@property (nonatomic, strong) NSString *Avatar;
@property (nonatomic, strong) NSString *Auth;

@end
