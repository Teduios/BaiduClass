//
//  ZQSchoolCell.h
//  ChuanKe
//
//  Created by tarena on 15/8/9.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZQSchoolModel.h"

@protocol ZQSchoolDelegate <NSObject>

@optional
- (void)didSelectedAtIndex:(NSInteger)index;

@end

@interface ZQSchoolCell : UITableViewCell

@property (nonatomic, strong) ZQSchoolModel *schoolModel;
@property (nonatomic, weak) id<ZQSchoolDelegate> delegate;

@end
