//
//  ZQAllCourseCell.h
//  ChuanKe
//
//  Created by tarena on 15/8/9.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZQAllCourseModel.h"
#import "ZQCategoryModel.h"

@interface ZQAllCourseCell : UITableViewCell
//学校查看所有课程传参时用
@property (nonatomic, strong) ZQAllCourseModel *allCourseModel;
//课程分类模块传参时用
@property (nonatomic, strong) ZQCategoryModel *categoryModel;

@end
