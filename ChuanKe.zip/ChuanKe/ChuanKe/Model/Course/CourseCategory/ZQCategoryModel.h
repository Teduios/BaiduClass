//
//  ZQCategoryModel.h
//  ChuanKe
//
//  Created by tarena on 15/8/10.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZQCategoryModel : NSObject

//非直播：http://pop.client.chuanke.com/?mod=search&act=mobile&from=iPhone&page=1&limit=20&cateid=72351176527446016&charge=1
//直播：http://pop.client.chuanke.com/?mod=search&act=mobile&from=iPhone&page=1&limit=20&today=1&charge=1
@property(nonatomic, strong) NSString *CourseID;
@property(nonatomic, strong) NSString *CourseName;
@property(nonatomic, strong) NSString *SID;
@property(nonatomic, strong) NSString *SchoolName;
@property(nonatomic, strong) NSNumber *PrelectStartTime;

@property(nonatomic, strong) NSString *ClassNumber;
@property(nonatomic, strong) NSString *ExpiryTime;
@property(nonatomic, strong) NSString *PayEndTime;
@property(nonatomic, strong) NSString *Cost;
@property(nonatomic, strong) NSString *PhotoURL;

@property(nonatomic, strong) NSString *Brief;
@property(nonatomic, strong) NSString *StudentNumber;
@property(nonatomic, strong) NSString *PayStudentLimit;

@end
