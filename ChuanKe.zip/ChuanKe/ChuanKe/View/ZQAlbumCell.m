//
//  ZQAlbumCell.m
//  ChuanKe
//
//  Created by tarena on 15/8/7.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQAlbumCell.h"
#import "UIImageView+WebCache.h"

#define MARGIN 5

@interface ZQAlbumCell ()
{
    UIScrollView *_scrollView;
}
@end

@implementation ZQAlbumCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier frame:(CGRect)frame {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(MARGIN, 0, frame.size.width, frame.size.height)];
        _scrollView.showsHorizontalScrollIndicator = NO;
        //_scrollView.bounces = NO;
        [self addSubview:_scrollView];
        
        //添加图片
        for (int i = 0; i < 10; ++i) {
            UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake((screen_width*2/5+MARGIN)*i, MARGIN, screen_width*2/5, frame.size.height-2*MARGIN)];
            //maskToBounds属性决定子图层是否相对于父图层裁剪
            imageView.layer.masksToBounds = YES;
            imageView.layer.cornerRadius = MARGIN;
            imageView.tag = i + 20;
            
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapImage:)];
            imageView.userInteractionEnabled = YES;
            [imageView addGestureRecognizer:tap];
            [_scrollView addSubview:imageView];
        }
    }
    return self;
}

- (void)setImageUrlArray:(NSArray *)imageUrlArray {
    _scrollView.contentSize = CGSizeMake((screen_width*2/MARGIN+MARGIN)*imageUrlArray.count+MARGIN, _scrollView.frame.size.height);
    for (int i = 0; i < imageUrlArray.count; i++) {
        UIImageView *imageView = (UIImageView *)[_scrollView viewWithTag:i + 20];
        [imageView sd_setImageWithURL:[NSURL URLWithString:imageUrlArray[i]] placeholderImage:[UIImage imageNamed:@"lesson_default"]];
    }
}

- (void)onTapImage:(UITapGestureRecognizer *)sender {
    UIImageView *imageView = (UIImageView *)sender.view;
    NSInteger tag = imageView.tag - 20;
    [self.delegate didSelectedAlbumAtIndex:tag];
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
