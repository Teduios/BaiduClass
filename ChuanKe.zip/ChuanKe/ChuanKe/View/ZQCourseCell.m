//
//  ZQCourseCell.m
//  ChuanKe
//
//  Created by tarena on 15/8/7.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQCourseCell.h"
#import "UIImageView+WebCache.h"

@interface ZQCourseCell ()
{
    //图片
    UIImageView *_imageView;
    //大标题
    UILabel *_titleLabel;
    //小标题
    UILabel *_subtitleLabel;
}
@end

@implementation ZQCourseCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initViews];
    }
    return self;
}

- (void)initViews {
    _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 70, 52)];
    [self addSubview:_imageView];
    
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(90, 5, screen_width - 100, 30)];
    [self addSubview:_titleLabel];
    
    _subtitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(90, 30, screen_width - 100, 40)];
    _subtitleLabel.font = [UIFont systemFontOfSize:13];
    _subtitleLabel.textColor = [UIColor lightGrayColor];
    _subtitleLabel.numberOfLines = 2;
    [self addSubview:_subtitleLabel];
}

- (void)setCourseModel:(ZQCourseListModel *)courseModel {
    //注意死循环!!!
    _courseModel = courseModel;
    [_imageView sd_setImageWithURL:[NSURL URLWithString:courseModel.PhotoURL] placeholderImage:[UIImage imageNamed:@"lesson_default"]];
    _titleLabel.text = courseModel.CourseName;
    _subtitleLabel.text = courseModel.Brief;
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
