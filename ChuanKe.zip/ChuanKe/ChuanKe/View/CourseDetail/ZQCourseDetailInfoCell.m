//
//  ZQCourseDetailInfoCell.m
//  ChuanKe
//
//  Created by tarena on 15/8/8.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQCourseDetailInfoCell.h"
#import "UIImageView+WebCache.h"

@interface ZQCourseDetailInfoCell ()
{
    UIImageView *_imageView;
    UILabel *_courseNameLabel;
    UILabel *_priceLabel;
    UIImageView *_numsImageView;
    UILabel *_numsLabel;
    UILabel *_schoolNameLabel;
}

@end

@implementation ZQCourseDetailInfoCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = navigationBarColor;
        [self initViews];
    }
    return self;
}

- (void)initViews {
    _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 70, 52)];
    [self addSubview:_imageView];
    
    _courseNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(90, 10, screen_width - 100, _imageView.frame.size.height)];
    _courseNameLabel.textColor = [UIColor whiteColor];
    _courseNameLabel.numberOfLines = 2;
    [self addSubview:_courseNameLabel];
    //CGRectGetMaxY(rect) 获得rect的y+height
    _priceLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(_imageView.frame)+15, 80, 30)];
    _priceLabel.textColor = [UIColor whiteColor];
    _priceLabel.font = [UIFont systemFontOfSize:15];
    _priceLabel.text = @"¥ 免费";
    [self addSubview:_priceLabel];
    
    _numsImageView = [[UIImageView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_priceLabel.frame)+15, _priceLabel.frame.origin.y+5, 18, 18)];
    [_numsImageView setImage:[UIImage imageNamed:@"course_studs_nums"]];
    [self addSubview:_numsImageView];
    
    _numsLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_numsImageView.frame)+10, _priceLabel.frame.origin.y, 60, _priceLabel.frame.size.height)];
    _numsLabel.textColor = [UIColor whiteColor];
    _numsLabel.font = [UIFont systemFontOfSize:15];
    [self addSubview:_numsLabel];
    
    _schoolNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(screen_width-15-130, _priceLabel.frame.origin.y, 130, 25)];
    _schoolNameLabel.textColor = [UIColor whiteColor];
    _schoolNameLabel.font = [UIFont systemFontOfSize:13];
    //切图
    _schoolNameLabel.layer.cornerRadius = 3;
    _schoolNameLabel.layer.masksToBounds = YES;
    _schoolNameLabel.layer.borderWidth = 1;
    _schoolNameLabel.layer.borderColor = [RGB(46, 158, 138) CGColor];
    [self addSubview:_schoolNameLabel];
    //添加点击事件
    _schoolNameLabel.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapSchoolLabel:)];
    [_schoolNameLabel addGestureRecognizer:tap];
    //箭头
    UIImageView *arrowImageView = [[UIImageView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_schoolNameLabel.frame)-13, CGRectGetMinY(_schoolNameLabel.frame), 13, 25)];
    [arrowImageView setImage:[UIImage imageNamed:@"course_school_classify_icon"]];
    [self addSubview:arrowImageView];
}

- (void)setCourseDetailModel:(ZQCourseDetailModel *)courseDetailModel {
    _courseDetailModel = courseDetailModel;
    [_imageView sd_setImageWithURL:[NSURL URLWithString:courseDetailModel.PhotoURL] placeholderImage:[UIImage imageNamed:@"lesson_default"]];
    
    _courseNameLabel.text = courseDetailModel.CourseName;
    
    _numsLabel.text = [NSString stringWithFormat:@"%@人",courseDetailModel.StudentNumber];
    _schoolNameLabel.text = [NSString stringWithFormat:@" %@",courseDetailModel.SchoolName];
    
    if ([courseDetailModel.Cost isEqualToString:@"0"]) {
        _priceLabel.text = @"¥ 免费";
    }else {
        int cost = [courseDetailModel.Cost intValue];
        _priceLabel.text = [NSString stringWithFormat:@"¥ %.2f",cost/100.0];
    }
}

- (void)onTapSchoolLabel:(UITapGestureRecognizer *)sender {
    [self.delegate didSelsctedSchool];
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end






