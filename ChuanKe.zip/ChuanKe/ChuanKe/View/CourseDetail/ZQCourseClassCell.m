


//
//  ZQCourseClassCell.m
//  ChuanKe
//
//  Created by tarena on 15/8/8.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQCourseClassCell.h"

@interface ZQCourseClassCell ()
{
    UIImageView *_imageView;
    UILabel *_classNameLabel;
    UILabel *_classTimeLabel;
}

@end

@implementation ZQCourseClassCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(16, 0, 1, 64)];
        lineView.backgroundColor = navigationBarColor;
        [self addSubview:lineView];
        
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(7, 22, 20, 20)];
        _imageView.image = [UIImage imageNamed:@"course_class_study_status_not"];
        [self addSubview:_imageView];
        
        _classNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(50, 5, screen_width-10-50, 25)];
        _classNameLabel.font = [UIFont systemFontOfSize:15];
        [self addSubview:_classNameLabel];
        
        _classTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(_classNameLabel.frame.origin.x, CGRectGetMaxY(_classNameLabel.frame), _classNameLabel.frame.size.width, 25)];
        _classTimeLabel.textColor = [UIColor lightGrayColor];
        _classTimeLabel.font = [UIFont systemFontOfSize:13];
        [self addSubview:_classTimeLabel];
    }
    return self;
}


- (void)setClassModel:(ZQClassListModel *)classModel {
    _classModel = classModel;
    _classNameLabel.text = [NSString stringWithFormat:@"第%@节:%@",classModel.index,classModel.ClassName];
    
    int time = [classModel.VideoTimeLength intValue];
    _classTimeLabel.text = [NSString stringWithFormat:@"课程时长: %d分钟",time / 60];
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
