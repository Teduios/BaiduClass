//
//  ZQEvalCell.h
//  ChuanKe
//
//  Created by tarena on 15/8/8.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZQEvalModel.h"

@interface ZQEvalCell : UITableViewCell

@property (nonatomic, strong) ZQEvalModel *evalModel;

@end
