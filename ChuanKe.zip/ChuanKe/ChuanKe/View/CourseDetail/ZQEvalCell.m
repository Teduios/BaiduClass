//
//  ZQEvalCell.m
//  ChuanKe
//
//  Created by tarena on 15/8/8.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQEvalCell.h"
#import "UIImageView+WebCache.h"

#define MARGIN 5

@interface ZQEvalCell ()
{
    UIImageView *_imageView;
    UILabel *_nickNameLabel;
    UILabel *_voteTextLabel;
    UILabel *_createTimeLabel;
    
    UIView *_lineView;
}
@end

@implementation ZQEvalCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 60, 60)];
        _imageView.layer.masksToBounds = YES;
        _imageView.layer.cornerRadius = 30;
        [self addSubview:_imageView];
        
        _nickNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_imageView.frame)+10, 10, screen_width-10-10-CGRectGetMaxX(_imageView.frame), 20)];
        _nickNameLabel.textColor = navigationBarColor;
        _nickNameLabel.font = [UIFont systemFontOfSize:15];
        [self addSubview:_nickNameLabel];
        
        _voteTextLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_imageView.frame)+10, CGRectGetMaxY(_nickNameLabel.frame)+MARGIN, _nickNameLabel.frame.size.width, 20)];
        _voteTextLabel.font = [UIFont systemFontOfSize:13];
        _voteTextLabel.textColor = [UIColor lightGrayColor];
        _voteTextLabel.numberOfLines = 0;
        [self addSubview:_voteTextLabel];
        
        _createTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_imageView.frame)+10, CGRectGetMaxY(_voteTextLabel.frame)+MARGIN, _nickNameLabel.frame.size.width, 20)];
        _createTimeLabel.textColor = [UIColor lightGrayColor];
        _createTimeLabel.font = [UIFont systemFontOfSize:13];
        [self addSubview:_createTimeLabel];
        
        _lineView = [[UIView alloc] initWithFrame:CGRectMake(70, CGRectGetMaxY(_createTimeLabel.frame)+MARGIN-0.5, screen_width-70, 0.5)];
        _lineView.backgroundColor = separaterColor;
        [self addSubview:_lineView];
    }
    return self;
}

- (void)setEvalModel:(ZQEvalModel *)evalModel {
    _evalModel = evalModel;
    [_imageView sd_setImageWithURL:[NSURL URLWithString:_evalModel.Avatar] placeholderImage:[UIImage imageNamed:@"lesson_default"]];
    if (!evalModel.NickName) {
        _nickNameLabel.text = @"匿名";
    }else{
        _nickNameLabel.text = evalModel.NickName;
    }
    
    _voteTextLabel.text = evalModel.VoteText;
    _createTimeLabel.text = [NSString stringWithFormat:@"发布时间:%@",evalModel.CreateTimeToDate];
    //设置frame
    _voteTextLabel.frame = CGRectMake(80, 30+5, screen_width-80-10, evalModel.voteTextHeight);
    _createTimeLabel.frame = CGRectMake(80, CGRectGetMaxY(_voteTextLabel.frame)+MARGIN, screen_width-80-10, 20);
    _lineView.frame = CGRectMake(80, CGRectGetMaxY(_createTimeLabel.frame)+MARGIN-0.5, screen_width-80, 0.5);
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
