//
//  ZQCourseDetailInfoCell.h
//  ChuanKe
//
//  Created by tarena on 15/8/8.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZQCourseDetailModel.h"

@protocol ZQCourseDetailInfoDelegate <NSObject>

@optional
- (void)didSelsctedSchool;

@end

@interface ZQCourseDetailInfoCell : UITableViewCell

@property (nonatomic, strong) ZQCourseDetailModel *courseDetailModel;
@property (nonatomic, weak) id<ZQCourseDetailInfoDelegate> delegate;

@end




