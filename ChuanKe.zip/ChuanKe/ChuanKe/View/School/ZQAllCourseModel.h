//
//  ZQAllCourseModel.h
//  ChuanKe
//
//  Created by tarena on 15/8/9.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZQAllCourseModel : NSObject
//http://pop.client.chuanke.com/?mod=school&act=info&do=courseList&sid=1827213&uid=4597633
@property(nonatomic, strong) NSString *CourseID;
@property(nonatomic, strong) NSString *PhotoURL;
@property(nonatomic, strong) NSString *Cost;
@property(nonatomic, strong) NSString *CourseName;
@property(nonatomic, strong) NSString *StudentNumber;

@property(nonatomic, strong) NSString *ClassNumber;
@property(nonatomic, strong) NSNumber *PrelectTime;

@end
