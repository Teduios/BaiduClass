
//
//  ZQSchoolModel.m
//  ChuanKe
//
//  Created by tarena on 15/8/9.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQSchoolModel.h"

@implementation ZQSchoolModel

@end
