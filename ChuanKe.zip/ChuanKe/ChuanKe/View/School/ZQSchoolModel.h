//
//  ZQSchoolModel.h
//  ChuanKe
//
//  Created by tarena on 15/8/9.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZQSchoolModel : NSObject
//http://pop.client.chuanke.com/?mod=school&act=info&mode=&sid=1959296&uid=4597633
@property (nonatomic, strong) NSString *SchoolName;
@property (nonatomic, strong) NSString *PrelectNum;
@property (nonatomic, strong) NSString *SchoolLogoUrl;
@property (nonatomic, strong) NSString *HasCollect;
@property (nonatomic, strong) NSMutableArray *TeacherList;

@property (nonatomic, strong) NSString *Brief;
@property (nonatomic, strong) NSString *NickName;
@property (nonatomic, strong) NSNumber *TotalAppraise;
@property (nonatomic, strong) NSString *CreateTime;
@property (nonatomic, strong) NSString *Notice;

@property (nonatomic, strong) NSString *GoodRate;
@property (nonatomic, strong) NSString *CourseSaleNumber;
@property (nonatomic, strong) NSString *CollectNumber;
@property (nonatomic, strong) NSString *StudentNumber;
@property (nonatomic, strong) NSString *ChannelID;

@property (nonatomic, strong) NSString *HtmlBrief;

@end
