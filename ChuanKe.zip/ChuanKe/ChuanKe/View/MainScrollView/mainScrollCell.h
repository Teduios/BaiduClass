//
//  mainScrollCell.h
//  ChuanKe
//
//  Created by tarena on 15/8/7.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainScrollView.h"

@interface MainScrollCell : UITableViewCell
//注意tableViewCell有scrollView属性!!!
@property (nonatomic, strong) MainScrollView *imageScrollView;
@property (nonatomic, strong) NSArray *imageArr;

- (void)setImageArray:(NSArray *)imageArray;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier frame:(CGRect)frame;

@end
