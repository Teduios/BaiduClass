//
//  mainScrollView.m
//  ChuanKe
//
//  Created by tarena on 15/8/6.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "MainScrollView.h"
#import "UIImageView+WebCache.h"

@interface MainScrollView ()<UIScrollViewDelegate>

@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, assign) NSInteger pageNumber;

@end

@implementation MainScrollView

- (MainScrollView *)initWithFrame:(CGRect)frame imageArray:(NSArray *)imageArray {
    self = [self initWithFrame:frame];
    if (self) {
        self.scrollView = [[UIScrollView alloc] initWithFrame:frame];
        self.scrollView.contentSize = CGSizeMake(4 *screen_width, frame.size.height);
        self.scrollView.pagingEnabled = YES;
        self.scrollView.showsHorizontalScrollIndicator = NO;
        self.scrollView.delegate = self;
        //添加图片
        for (int i = 0; i < 10; i++) {
            UIImageView *imageView = [[UIImageView alloc] init];
            //高度有误
            imageView.frame = CGRectMake(i * screen_width, 0, screen_width, frame.size.height);
            imageView.tag = i + 10;
            //添加点击事件
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapImage:)];
            [imageView addGestureRecognizer:tap];
            imageView.userInteractionEnabled = YES;
            [self.scrollView addSubview:imageView];
        }
        [self addSubview:self.scrollView];
        //添加pagecontroller
        self.pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(screen_width/2 - 40, frame.size.height - 30, 80, 30)];
        self.pageControl.currentPage = 0;
        self.pageControl.numberOfPages = 6;
        self.pageControl.pageIndicatorTintColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.4];
        [self addSubview:self.pageControl];
        
        [self addTimer];
    }
    return self;
}

- (void)setImageArray:(NSArray *)imageArray {
    _pageNumber = imageArray.count;
    self.scrollView.contentSize = CGSizeMake(imageArray.count * screen_width, self.frame.size.height);
    self.pageControl.numberOfPages = imageArray.count;
    //添加图片
    for (int i = 0; i < imageArray.count; i++) {
        UIImageView *imageView = (UIImageView *)[self.scrollView viewWithTag:i + 10];
        //imageView.backgroundColor = [UIColor redColor];
        NSString *imageName = [NSString stringWithFormat:@"%@",imageArray[i]];
        //NSLog(@"%@",imageName);
        //下载图片
        [imageView sd_setImageWithURL:[NSURL URLWithString:imageName] placeholderImage:[UIImage imageNamed:@"lesson_default"]];
    }
}

- (void)onTapImage:(UITapGestureRecognizer *)sender {
    //取出点击imageView
    UIImageView *imageView = (UIImageView *)sender.view;
    NSInteger tag = imageView.tag - 10;
    //代理方法
    [self.delegate didSelectImageAtIndex:tag];
}

- (void)addTimer {
    self.timer = [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(next) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
}

- (void)removeTimer {
    [self.timer invalidate];
}

- (void)next {
    NSInteger page = self.pageControl.currentPage;
    if (page == self.pageNumber - 1) {
        page = 0;
    }else {
        page++;
    }
    CGFloat x = page * self.scrollView.frame.size.width;
    [self.scrollView setContentOffset:CGPointMake(x, 0) animated:YES];
}

#pragma mark -- scrollView delegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    CGFloat width = scrollView.frame.size.width;
    CGFloat x = scrollView.contentOffset.x;
    NSInteger page = (x + width / 2) / width;
    self.pageControl.currentPage = page;
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [self removeTimer];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    [self addTimer];
}

- (void)dealloc {
    [self removeTimer];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
