//
//  mainScrollView.h
//  ChuanKe
//
//  Created by tarena on 15/8/6.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol mainScrollViewDelegate <NSObject>

- (void)didSelectImageAtIndex:(NSInteger)index;

@end

@interface MainScrollView : UIView

@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIPageControl *pageControl;
@property (nonatomic, strong) NSArray *imageArray;
@property (nonatomic, weak) id<mainScrollViewDelegate> delegate;

- (void)setImageArray:(NSArray *)imageArray;
- (MainScrollView *)initWithFrame:(CGRect)frame imageArray:(NSArray *)imageArray;

@end
