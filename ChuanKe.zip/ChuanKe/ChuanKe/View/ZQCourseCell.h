//
//  ZQCourseCell.h
//  ChuanKe
//
//  Created by tarena on 15/8/7.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZQCourseListModel.h"

@interface ZQCourseCell : UITableViewCell

//课程精选界面cell
@property (nonatomic, strong) ZQCourseListModel *courseModel;

@end
