//
//  ZQAlbumCell.h
//  ChuanKe
//
//  Created by tarena on 15/8/7.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ZQAlbumDelegate <NSObject>

@optional
- (void)didSelectedAlbumAtIndex:(NSInteger)index;

@end

@interface ZQAlbumCell : UITableViewCell

//课程精选界面横向滑动cell
@property (nonatomic, strong) NSArray *imageUrlArray;

@property (nonatomic, weak) id<ZQAlbumDelegate> delegate;

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier frame:(CGRect)frame;

@end
