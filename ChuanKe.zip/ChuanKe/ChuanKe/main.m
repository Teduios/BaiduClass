//
//  main.m
//  ChuanKe
//
//  Created by tarena on 15/8/6.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
