//
//  UITabBarItem+Category.m
//  ChuanKe
//
//  Created by tarena on 15/8/6.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "UITabBarItem+Category.h"

@implementation UITabBarItem (Category)

- (void)setImageName:(NSString *)imageName selectedImageName:(NSString *)selImageName {
    self.image = [[UIImage imageNamed:imageName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    self.selectedImage = [[UIImage imageNamed:selImageName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

@end
