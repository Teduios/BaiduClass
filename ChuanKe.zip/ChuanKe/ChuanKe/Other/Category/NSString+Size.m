//
//  NSString+Size.m
//  ChuanKe
//
//  Created by tarena on 15/8/6.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "NSString+Size.h"

@implementation NSString (Size)

- (CGSize)boundingRectWithSize:(CGSize)size withFont:(NSInteger)font {
    NSDictionary *attribute = @{NSFontAttributeName : [UIFont systemFontOfSize:font]};
    //size:宽度限制 该方法返回文本所占矩形空间
    CGSize rectSize = [self boundingRectWithSize:size options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:attribute context:nil].size;
    return rectSize;
}

@end
