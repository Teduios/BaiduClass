//
//  NSString+Size.h
//  ChuanKe
//
//  Created by tarena on 15/8/6.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSString (Size)

- (CGSize)boundingRectWithSize:(CGSize)size withFont:(NSInteger)font;

@end
