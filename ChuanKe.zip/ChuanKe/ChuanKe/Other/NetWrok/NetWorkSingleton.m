//
//  NetWorkSingleton.m
//  ChuanKe
//
//  Created by tarena on 15/8/7.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "NetWorkSingleton.h"

@implementation NetWorkSingleton

//两种编码方式
//前者搜索
//NSString *urlStr = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//    NSString *urlStr = [url stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

+ (NetWorkSingleton *)sharedManger {
    static NetWorkSingleton *sharedNetWorkSingleton = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        sharedNetWorkSingleton = [[self alloc] init];
    });
    return sharedNetWorkSingleton;
}

- (AFHTTPRequestOperationManager *)baseHttpRequest {
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager.requestSerializer setTimeoutInterval:TIMEOUT];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/plain", @"text/html", @"application/json", nil];
    return manager;
}
//重写
- (void)getResult:(NSDictionary *)userInfo url:(NSString *)url successBlock:(SuccessBlock)successBlock failureBlock:(FailureBlock)failBlock {
    AFHTTPRequestOperationManager *manager = [self baseHttpRequest];
    NSString *urlStr = [url stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [manager GET:urlStr parameters:userInfo success:^(AFHTTPRequestOperation *operation, id responseObject) {
        successBlock(responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        failBlock(error.userInfo[@"NSLocalizedDescription"]);
    }];
}

#pragma mark -- 获取推荐课程内容
- (void)getRecommendCourseResult:(NSDictionary *)userInfo url:(NSString *)url successBlock:(SuccessBlock)successBlock failureBlock:(FailureBlock)failBlock {
    [self getResult:userInfo url:url successBlock:successBlock failureBlock:failBlock];
}

#pragma mark -- 获取课程详情
- (void)getClassListResult:(NSDictionary *)userInfo url:(NSString *)url successBlock:(SuccessBlock)successBlock failureBlock:(FailureBlock)failBlock {
    [self getResult:userInfo url:url successBlock:successBlock failureBlock:failBlock];
}

#pragma mark -- 获取课程评价
- (void)getClassEvalResult:(NSDictionary *)userInfo url:(NSString *)url successBlock:(SuccessBlock)successBlock failureBlock:(FailureBlock) failBlock {
    [self getResult:userInfo url:url successBlock:successBlock failureBlock:failBlock];
}

#pragma mark -- Get
- (void)getDataResult:(NSDictionary *)userInfo url:(NSString *)url successBlock:(SuccessBlock)successBlock failureBlock:(FailureBlock)failBlock {
    [self getResult:userInfo url:url successBlock:successBlock failureBlock:failBlock];
}

#pragma mark -- 获取搜索课程信息
- (void)getSearchResult:(NSDictionary *)userInfo url:(NSString *)url successBlock:(SuccessBlock)successBlock failureBlock:(FailureBlock)failBlock {
    AFHTTPRequestOperationManager *manger = [self baseHttpRequest];
    NSString *urlStr = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [manger GET:urlStr parameters:userInfo success:^(AFHTTPRequestOperation *operation, id responseObject) {
        successBlock(responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSString *errorStr = [error.userInfo objectForKey:@"NSLocalizedDescription"];
        failBlock(errorStr);
    }];
}

@end















