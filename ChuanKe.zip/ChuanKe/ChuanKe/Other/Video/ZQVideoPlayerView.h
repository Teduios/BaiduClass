//
//  ZQVideoPlayerView.h
//  ChuanKe
//
//  Created by tarena on 15/8/11.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>

@class ZQVideoPlayerView;

@protocol ZQVideoPlayerViewDelegate <NSObject>

@optional
- (void)playerViewZoomButtonClicked:(ZQVideoPlayerView *)view;
- (void)onTapBackButton;

@end

@interface ZQVideoPlayerView : UIView

@property (nonatomic, weak) id<ZQVideoPlayerViewDelegate> delegate;

@property (nonatomic, strong) AVPlayerItem *playerItem;
@property (nonatomic, strong) AVPlayer *player;
@property (nonatomic, strong) AVPlayerLayer *playerLayer;
@property (nonatomic, strong) NSString *contentStr;
@property (nonatomic, strong) NSURL *contentURL;
@property (nonatomic, assign) BOOL isFullScreen;
@property (nonatomic, assign) BOOL isPlaying;
@property (nonatomic, assign) BOOL isBuffering;

@property (nonatomic, strong) UIButton *playButton;//播放/暂停
@property (nonatomic, strong) UIButton *zoomButton;//全屏/不全屏
@property (nonatomic, strong) UISlider *progressSlider;//播放进度条
@property (nonatomic, strong) UIProgressView *loadProgressView;//缓存进度条
@property (nonatomic, strong) UILabel *playTime;//已播放时间
@property (nonatomic, strong) UILabel *totalTime;//总时间
@property (nonatomic, strong) UIButton *backButton;//返回按钮

@property(nonatomic, strong) UIView *playerHUDBottomView;
@property(nonatomic, strong) UIView *playerHUDTopView;

/**
 * NSURL初始化
 */
- (instancetype)initWithFrame:(CGRect)frame contentURL:(NSURL *)contentURL;
/**
 * 播放
 */
- (void)play;
/**
 * 暂停
 */
- (void)pause;
/**
 * 停止
 */
- (void)stop;

@end
