//
//  ZQVideoPlayerView.m
//  ChuanKe
//
//  Created by tarena on 15/8/11.
//  Copyright (c) 2015年 com.tarena. All rights reserved.
//

#import "ZQVideoPlayerView.h"

@interface ZQVideoPlayerView ()
{
    id playbackObserver;
    
    UIView *loadView;
    UIActivityIndicatorView *activityIndicatorView;//加载指示器
    NSTimer *timer;
    BOOL viewIsShowing;
}

@end

@implementation ZQVideoPlayerView

- (instancetype)initWithFrame:(CGRect)frame contentURL:(NSURL *)contentURL {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor blackColor];
        self.playerItem = [AVPlayerItem playerItemWithURL:contentURL];
        self.player = [AVPlayer playerWithPlayerItem:self.playerItem];
        self.playerLayer = [AVPlayerLayer playerLayerWithPlayer:self.player];
        self.playerLayer.frame = frame;
        [self.layer addSublayer:self.playerLayer];
        
        [self initLoadingView];
        [self initControlView];
        viewIsShowing = YES;
        //添加监听事件
        [self addNotification];
        [self addObserverToPlayerItem:self.playerItem];
        [self addProgressObserver];
    }
    return self;
}

- (void)play {
    [self.player play];
    self.isPlaying = YES;
    [self.playButton setSelected:YES];
}

- (void)pause {
    [self.player pause];
    self.isPlaying = NO;
    [self.playButton setSelected:NO];
}

- (void)stop {
    NSLog(@"stoppppppppppp");
}

- (void)initLoadingView {
    loadView = [[UIView alloc] initWithFrame:self.playerLayer.frame];
    NSLog(@"playerLayer:=====%f   %f",self.playerLayer.frame.size.width,self.playerLayer.frame.size.height);
    loadView.backgroundColor = [UIColor clearColor];
    
    activityIndicatorView = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [activityIndicatorView setCenter:loadView.center];
    [activityIndicatorView setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleWhiteLarge];
    [activityIndicatorView startAnimating];
    [loadView addSubview:activityIndicatorView];
    
    [self addSubview:loadView];
}

//初始化播放,进度条,时间视图
- (void)initControlView {
    int frameWidth = self.frame.size.width;
    int frameHeight = self.frame.size.height;
    //上面遮罩
    self.playerHUDTopView = [[UIView alloc] initWithFrame:CGRectMake(0, 20, frameWidth, 44)];
    [self addSubview:self.playerHUDTopView];
    //返回按钮
    self.backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.backButton.frame = CGRectMake(15, 0, 30, 30);
    [self.backButton addTarget:self action:@selector(clickBack) forControlEvents:UIControlEventTouchUpInside];
    [self.backButton setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [self.playerHUDTopView addSubview:self.backButton];
    
    //下面遮罩
    self.playerHUDBottomView = [[UIView alloc] initWithFrame:CGRectMake(0, frameHeight-44, frameWidth, 44)];
    self.playerHUDBottomView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
    [self addSubview:self.playerHUDBottomView];
    //播放暂停按钮
    self.playButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.playButton.frame = CGRectMake(8, 10, 20, 20);
    [self.playButton addTarget:self action:@selector(clickPlay) forControlEvents:UIControlEventTouchUpInside];
    [self.playButton setSelected:NO];
    [self.playButton setBackgroundImage:[UIImage imageNamed:@"player_btn_pause_normal"] forState:UIControlStateSelected];
    [self.playButton setBackgroundImage:[UIImage imageNamed:@"player_btn_play_normal"] forState:UIControlStateNormal];
    [self.playButton setTintColor:[UIColor clearColor]];
    [self.playerHUDBottomView addSubview:self.playButton];
    //全屏按钮
    self.zoomButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.zoomButton.frame = CGRectMake(frameWidth-27, 10, 20, 20);
    [self.zoomButton addTarget:self action:@selector(clickZoom) forControlEvents:UIControlEventTouchUpInside];
    [self.zoomButton setSelected:NO];
    [self.zoomButton setBackgroundImage:[UIImage imageNamed:@"zoomout1"] forState:UIControlStateSelected];
    [self.zoomButton setBackgroundImage:[UIImage imageNamed:@"zoomin1"] forState:UIControlStateNormal];
    [self.zoomButton setTintColor:[UIColor clearColor]];
    [self.playerHUDBottomView addSubview:self.zoomButton];
    //缓存进度条
    self.loadProgressView = [[UIProgressView alloc] init];
    self.loadProgressView.frame = CGRectMake(32, 17, frameWidth-60, 14);
    self.loadProgressView.progressViewStyle = UIProgressViewStyleBar;
    self.loadProgressView.progressTintColor = RGB(181, 181, 181);
    self.loadProgressView.backgroundColor = [UIColor whiteColor];
    self.loadProgressView.progress = 0;
    [self.playerHUDBottomView addSubview:self.loadProgressView];
    //播放进度条
    self.progressSlider = [[UISlider alloc] initWithFrame:CGRectMake(30, 11, frameWidth-60, 14)];
    [self.progressSlider addTarget:self action:@selector(progressSliderChanged:) forControlEvents:UIControlEventValueChanged];
    [self.progressSlider addTarget:self action:@selector(progressSliderChangeEnded:) forControlEvents:UIControlEventTouchUpInside];
    //颜色
    [self.progressSlider setMinimumTrackTintColor:RGB(58, 193, 126)];
    [self.progressSlider setMaximumTrackTintColor:[UIColor clearColor]];
    [self.progressSlider setThumbTintColor:[UIColor clearColor]];
    //图片
    UIImage *thumbImage = [UIImage imageNamed:@"account_cache_isplay"];
    [self.progressSlider setThumbImage:thumbImage forState:UIControlStateHighlighted];
    [self.progressSlider setThumbImage:thumbImage forState:UIControlStateNormal];
    [self.playerHUDBottomView addSubview:self.progressSlider];
    //播放时间
    self.playTime = [[UILabel alloc] initWithFrame:CGRectMake(30, 20, 200, 20)];
    self.playTime.text = @"00:00:00/00:00:00";
    self.playTime.font = [UIFont systemFontOfSize:13];
    self.playTime.textAlignment = NSTextAlignmentLeft;
    self.playTime.textColor = [UIColor whiteColor];
    [self.playerHUDBottomView addSubview:self.playTime];
}

#pragma mark -- 给AVPlayerItem添加监控
- (void)addObserverToPlayerItem:(AVPlayerItem *)playerItem {
    //监控状态属性，注意AVPlayer也有一个status属性，通过监控它的status也可以获得播放状态
    [playerItem addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:nil];
    //监控网络加载情况属性
    [playerItem addObserver:self forKeyPath:@"loadedTimeRanges" options:NSKeyValueObservingOptionNew context:nil];
    //监控缓冲区大小
    [playerItem addObserver:self forKeyPath:@"playbackBufferEmpty" options:NSKeyValueObservingOptionNew context:nil];
    [self performSelectorInBackground:@selector(initPlayTime) withObject:nil];
}

- (void)initPlayTime {
    NSString *currentTime = [self getStringFromCMTime:self.player.currentTime];
    NSString *totalTime = [self getStringFromCMTime:self.player.currentItem.asset.duration];
    self.playTime.text = [NSString stringWithFormat:@"%@/%@",currentTime,totalTime];
    NSLog(@"totalTime:%@",totalTime);
}
//移除KVO观察
- (void)removeObserverToPlayerItem:(AVPlayerItem *)playerItem {
    [playerItem removeObserver:self forKeyPath:@"status"];
    [playerItem removeObserver:self forKeyPath:@"loadedTimeRanges"];
    [playerItem removeObserver:self forKeyPath:@"playbackBufferEmpty"];
}

#pragma mark -- 观察视频播放各个监听触发
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if ([keyPath isEqualToString:@"status"]) {
        AVPlayerStatus status = [[change objectForKey:NSKeyValueChangeNewKey] integerValue];
        switch (status) {
            case AVPlayerStatusFailed:
                NSLog(@"播放失败");
                [loadView setHidden:NO];
                break;
            case AVPlayerStatusReadyToPlay:
                NSLog(@"正在播放---视频长度为:%f",CMTimeGetSeconds(self.playerItem.duration));
                [loadView setHidden:YES];
            default:
                NSLog(@"default");
                break;
        }
    }else if ([keyPath isEqualToString:@"loadedTimeRanges"]) {
        //缓冲
        NSArray *array = self.playerItem.loadedTimeRanges;
        //本次缓冲时间
        CMTimeRange timeRange = [array.firstObject CMTimeRangeValue];
        float startSeconds = CMTimeGetSeconds(timeRange.start);
        float durationSeconds = CMTimeGetSeconds(timeRange.duration);
        //缓冲总长度
        NSTimeInterval totalBuffer = startSeconds + durationSeconds;
        float durationTime = CMTimeGetSeconds([[self.player currentItem] duration]);
        [self.loadProgressView setProgress:totalBuffer/durationTime animated:YES];
        if (self.isBuffering && self.isPlaying) {
            [self.player play];
            self.isBuffering = NO;
        }
    }else if ([keyPath isEqualToString:@"playbackBufferEmpty"]) {
        if (self.player.currentItem.playbackBufferEmpty) {
            NSLog(@"缓冲区为空");
            self.isBuffering = YES;
        }else {
            NSLog(@"缓冲区不为空");
        }
    }
}

#pragma mark -- 添加计时器显示/隐藏播放栏
- (void)startTimer {
    if (timer == nil) {
        timer = [NSTimer scheduledTimerWithTimeInterval:5.0 target:self selector:@selector(initHUDViewShowing:) userInfo:nil repeats:YES];
    }
}

- (void)stopTimer {
    if (timer) {
        [timer invalidate];
        timer = nil;
    }
}

- (void)initHUDViewShowing:(NSTimer *)timer {
    [self showHUD:viewIsShowing];
}

- (void)showHUD:(BOOL)showing {
    __weak __typeof(self) weakSelf = self;
    viewIsShowing = !showing;
    if (showing) {
        weakSelf.playerHUDBottomView.hidden = YES;
        [weakSelf stopTimer];
    }else {
        weakSelf.playerHUDBottomView.hidden = NO;
        [weakSelf startTimer];
    }
}

#pragma mark -- 横屏,竖屏
- (void)layoutSubviews {
    [super layoutSubviews];
    //获取当前设备方向
    UIDeviceOrientation deviceOrientation = [[UIDevice currentDevice] orientation];
    if (UIDeviceOrientationIsLandscape(deviceOrientation)) {
        NSLog(@"横屏");
        [self initLandscape];
    }else {
        NSLog(@"竖屏");
        [self initPortraint];
    }
}

- (void)initLandscape {
    float frameWidth = self.frame.size.width;
    float frameHeight = self.frame.size.height;
    NSLog(@"横屏:width=%f   height=%f",frameWidth,frameHeight);
    //更新布局
    self.playerHUDBottomView.frame = CGRectMake(0, frameHeight-44, frameWidth, 44);
    self.zoomButton.frame = CGRectMake(frameWidth-27, 10, 20, 20);
    self.progressSlider.frame = CGRectMake(30, 11, frameWidth-60, 14);
    self.loadProgressView.frame = CGRectMake(32, 17, frameWidth-60, 14);
    [activityIndicatorView setCenter:self.center];
}

- (void)initPortraint {
    float frameWidth = self.frame.size.width;
    float frameHeight = self.frame.size.height;
    NSLog(@"竖屏:width=%f   height=%f",frameWidth,frameHeight);
    //更新布局
    self.playerHUDBottomView.frame = CGRectMake(0, frameHeight-44, frameWidth, 44);
    self.zoomButton.frame = CGRectMake(frameWidth-27, 10, 20, 20);
    self.progressSlider.frame = CGRectMake(30, 11, frameWidth-60, 14);
    self.loadProgressView.frame = CGRectMake(32, 17, frameWidth-60, 14);
    [activityIndicatorView setCenter:loadView.center];
}

#pragma mark -- 监听触摸事件
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    CGPoint point = [(UITouch *)[touches anyObject] locationInView:self];
    //触摸播放界面
    if (CGRectContainsPoint(self.playerLayer.frame, point)) {
        [self showHUD:viewIsShowing];
    }
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    NSLog(@"moved-------");
}

#pragma mark -- 获取时间
- (NSString *)getStringFromCMTime:(CMTime)time {
    Float64 currentSeconds = CMTimeGetSeconds(time);
    int min = currentSeconds/60.0;
    int hour = min/60.0;
    int second = fmodf(currentSeconds, 60.0);
    min = fmodf(min, 60.0f);
    
    NSString *hourStr = hour < 10 ? [NSString stringWithFormat:@"0%d",hour] : [NSString stringWithFormat:@"%d",hour];
    NSString *minStr = min < 10 ? [NSString stringWithFormat:@"0%d", min] : [NSString stringWithFormat:@"%d", min];
    NSString *secondStr = second < 10 ? [NSString stringWithFormat:@"0%d", second] : [NSString stringWithFormat:@"%d", second];
    
    return [NSString stringWithFormat:@"%@:%@:%@", hourStr,minStr, secondStr];
}

#pragma mark -- 添加播放完成通知
- (void)addNotification {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playBackFinished:) name:AVPlayerItemDidPlayToEndTimeNotification object:self.player.currentItem];
}

- (void)playBackFinished:(NSNotification *)notification {
    NSLog(@"视频播放完成");
}

#pragma mark -- 添加播放进度条更新
- (void)addProgressObserver {
    __weak __typeof(self) weakSelf = self;
    AVPlayerItem *playerItem = self.player.currentItem;
    NSLog(@"添加播放进度条更新");
    playbackObserver = [self.player addPeriodicTimeObserverForInterval:CMTimeMake(1.0, 1.0) queue:dispatch_get_main_queue() usingBlock:^(CMTime time) {
        float current = CMTimeGetSeconds(time);
        float total = CMTimeGetSeconds(playerItem.duration);
        //更新UI
        float progress = current / total;
        weakSelf.progressSlider.value = progress;
        NSString *currentTime = [weakSelf getStringFromCMTime:weakSelf.player.currentTime];
        NSString *totalTime = [weakSelf getStringFromCMTime:playerItem.duration];
        weakSelf.playTime.text = [NSString stringWithFormat:@"%@/%@",currentTime,totalTime];
    }];
}

- (void)setFrame:(CGRect)frame {
    [super setFrame:frame];
    [self.playerLayer setFrame:frame];
}

- (void)setIsFullScreen:(BOOL)isFullScreen {
    _isFullScreen = isFullScreen;
    if (isFullScreen) {
        
    }else {
        
    }
}

#pragma mark -- ClickButton
- (void)clickBack {
    if (self.isFullScreen) {
        self.isFullScreen = !self.isFullScreen;
        //代理方法
        [self.delegate playerViewZoomButtonClicked:self];
    }else {
        [self.delegate onTapBackButton];
    }
}

- (void)clickPlay {
    if (self.isPlaying) {
        [self pause];
    }else {
        [self play];
    }
}

- (void)clickZoom {
    self.isFullScreen = !self.isFullScreen;
    if (self.isFullScreen) {
        [self.zoomButton setSelected:YES];
    }else {
        [self.zoomButton setSelected:NO];
    }
    [self.delegate playerViewZoomButtonClicked:self];
}

#pragma mark -- progressChanged
- (void)progressSliderChanged:(UISlider *)sender {
    if (self.isPlaying) {
        [self.player pause];
    }
    //滑动时改变播放时间
    CMTime seekTime = CMTimeMakeWithSeconds(sender.value*(double)self.player.currentItem.asset.duration.value/(double)self.player.currentItem.asset.duration.timescale, self.player.currentTime.timescale);
    [self.player seekToTime:seekTime];
}

- (void)progressSliderChangeEnded:(UISlider *)sender {
    [self startTimer];
    if (self.isPlaying) {
        [self.player play];
    }
}

- (void)dealloc {
    [self removeObserverToPlayerItem:self.playerItem];
    [self.player removeTimeObserver:playbackObserver];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
